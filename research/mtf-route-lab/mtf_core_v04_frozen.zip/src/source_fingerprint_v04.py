#!/usr/bin/env python3
"""Independent exchange OHLCV probes against input bars, no trade signals.

A match on a single bar is necessary, not sufficient, for source authenticity.
The public Binance spot and futures reference observations were retrieved via
connected public-market tool on 2026-10-14 and archived unchanged as JSON.
"""
from __future__ import annotations
import argparse, json, math, sys
from pathlib import Path
from mtf_engine import load_csv, iso

DATA=Path(__file__).resolve().parents[1]/'data'/'BINANCE_PUBLIC_REFERENCE_OCT11_12.json'

def same(a,b):
    return all(math.isclose(float(x),float(y),rel_tol=1e-8,abs_tol=1e-7) for x,y in zip(a,b))

def classify(symbol,tf,bars,reference=DATA):
    probes=json.loads(Path(reference).read_text(encoding='utf-8'))['probes']
    by_start={b.start:b for b in bars}
    checks=[]
    for x in probes:
        if x['symbol']!=symbol or x['tf']!=tf:continue
        if x['open_time'] not in by_start:continue
        b=by_start[x['open_time']]
        obs=(b.o,b.h,b.l,b.c,b.v)
        result={'at':iso(x['open_time']),'observed':obs,
                'matches_futures':same(obs,x['futures_um']) if 'futures_um' in x else None,
                'matches_spot':same(obs,x['spot']) if 'spot' in x else None}
        checks.append(result)
    if any(r['matches_spot'] is True and r['matches_futures'] is not True for r in checks):
        status='MATCHES_SPOT_NOT_FUTURES'
    elif any(r['matches_futures'] is False for r in checks):
        status='DOES_NOT_MATCH_FUTURES_PROBE'
    elif any(r['matches_futures'] is True for r in checks):
        status='FUTURES_SAMPLE_MATCH_ONLY_NOT_FULL_PROOF'
    else:status='NO_REFERENCE_OVERLAP'
    return {'symbol':symbol,'tf':tf,'status':status,'checks':checks}

def fixture_report(root):
    root=Path(root)
    output={'status':'DIAGNOSTIC_FIXTURE_NOT_VALIDATED_FUTURES','files':{},'caveats':[]}
    for tf,name in [('15m','BTCUSDT_15m_KIMI_1000.csv'),('1d','BTCUSDT_1d_KIMI_60.csv')]:
        bars,_=load_csv(root/name,'BTCUSDT',tf)
        output['files'][name]=classify('BTCUSDT',tf,bars)
    # Inspect whether the very last archived BTC daily fixture is closed.
    output['caveats']=['Last daily/15m Kimi rows were snapshots of still-forming bars, despite full close_time columns',
                      'Earlier v0.3 paper returns are diagnostics using spot fixtures; not USD-M Futures estimates',
                      'Spot/futures sample match cannot alone prove exchange origin of entire dataset']
    return output

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--fixture-dir',default='data')
    p.add_argument('--out',default='results_04/LEGACY_FIXTURE_QUARANTINE.json')
    a=p.parse_args();r=fixture_report(a.fixture_dir)
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for name,result in r['files'].items():print(name,result['status'])
    return 0
if __name__=='__main__':sys.exit(main())
