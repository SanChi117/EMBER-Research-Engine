#!/usr/bin/env python3
"""Reject self-declared VISUALLY_VERIFIED labels without a traceable artifact.

Provenance metadata does not replace independent HUMAN review or geometric
annotation of the chart; the gate merely prevents an unbacked status flag from
counting as teacher-matched ground truth. Never creates fabricated labels.
"""
from __future__ import annotations
import argparse,hashlib,json,re,sys
from pathlib import Path
from urllib.parse import urlparse

HEX=re.compile(r'^[a-fA-F0-9]{64}$')
TYPES={'PIV_H','PIV_L','IMB','SNR','OB','RB','RAID'}

def validate(labels,root):
    root=Path(root).resolve()
    results=[]
    for item in labels:
        id_=item.get('id','MISSING_ID')
        reasons=[]
        if item.get('status')!='VISUALLY_VERIFIED':
            results.append({'id':id_,'status':'NOT_VERIFIED','reasons':['No independent verification claimed']})
            continue
        required=('id','source_url','source_page','symbol','tf','type','side','confirmed_at',
                  'lo','hi','reviewer_id','reviewed_at','image_sha256','image_path')
        for key in required:
            if key not in item or item[key] in (None,''):
                reasons.append('MISSING_'+key)
        url=str(item.get('source_url',''))
        p=urlparse(url)
        if p.scheme!='https' or not p.hostname:
            reasons.append('INVALID_SOURCE_URL')
        if item.get('type') not in TYPES or item.get('tf') not in ('15m','1h','4h','1d','1w'):
            reasons.append('INVALID_FEATURE_SCHEMA')
        if item.get('side') not in ('LONG','SHORT'):
            reasons.append('INVALID_SIDE')
        try:
            if not (0<float(item['lo'])<=float(item['hi'])):reasons.append('BAD_ZONE')
        except (KeyError,TypeError,ValueError):reasons.append('BAD_ZONE')
        rel=item.get('image_path')
        if rel:
            image=(root/str(rel)).resolve()
            if not image.is_relative_to(root):
                reasons.append('ARTIFACT_PATH_OUTSIDE_ROOT')
            elif not image.is_file():
                reasons.append('MISSING_IMAGE_FILE')
            else:
                digest=hashlib.sha256(image.read_bytes()).hexdigest()
                if not HEX.fullmatch(str(item.get('image_sha256',''))):
                    reasons.append('MISSING_SHA256')
                elif digest.lower()!=item['image_sha256'].lower():
                    reasons.append('SCREENSHOT_SHA256_MISMATCH')
        results.append({'id':id_,'status':'EVIDENCE_ATTACHED_NEEDS_HUMAN_REVIEW' if not reasons else 'UNVERIFIED_SOURCE',
                        'reasons':reasons})
    evidenced=sum(x['status']=='EVIDENCE_ATTACHED_NEEDS_HUMAN_REVIEW' for x in results)
    return {'status':'METADATA_CHECK_ONLY_NOT_VISUAL_TRUTH',
            'labels_claiming_verified':sum(x.get('status')=='VISUALLY_VERIFIED' for x in labels),
            'evidence_packages_with_valid_metadata':evidenced,
            'independently_human_verified':'NOT_MACHINE_ATTESTABLE',
            'cases_without_valid_evidence':sum(x['status']=='UNVERIFIED_SOURCE' for x in results),
            'results':results}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--labels',default='data/LABELS_TEMPLATE.json')
    p.add_argument('--image-root',default='data')
    p.add_argument('--out',default='results_04/LABEL_EVIDENCE.json')
    a=p.parse_args();r=validate(json.loads(Path(a.labels).read_text(encoding='utf-8')),a.image_root)
    dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(r['status'], 'evidence', r['evidence_packages_with_valid_metadata'],
          'unverified',r['cases_without_valid_evidence'])
    return 2 if r['cases_without_valid_evidence'] else 0
if __name__=='__main__':sys.exit(main())
