#!/usr/bin/env python3
"""Version-locked, read-only five-symbol replay. Refuses incomplete history.

This reports overlap-aware *limitations*, not a verified live portfolio.
Frozen FTA×cost grids are evaluated without selecting the winner.
"""
from __future__ import annotations
import argparse,hashlib,json,sys
from collections import Counter
from pathlib import Path
from mtf_engine import ALGO,load_csv,route_replay,ms,iso
from global_context import enrich
from validate_history_v03 import audit,SYMBOLS,DEFAULT_END

FTA=('COURSE_PARENT_FTA','V22_FIRST_OBSTACLE')
COSTS=(('BASE',.0005,.0002),('COST_X2',.001,.0004))
PHASES=(('APR_JUN','2026-04-01T00:00:00Z','2026-07-01T00:00:00Z'),
        ('JUL_AUG','2026-07-01T00:00:00Z','2026-09-01T00:00:00Z'),
        ('SEP_OCT','2026-09-01T00:00:00Z','2026-10-13T00:00:00Z'))
ROUTES=('A_VC_IMB_SNR','B_IDM','C_BOS_15M_PROXY')

def cohort(rows):
    stats={}
    for route in ROUTES:
        cur=[x for x in rows if x['route']==route]
        resolved=[x for x in cur if x.get('r') is not None]
        vals=[x['r'] for x in resolved]
        gain=sum(x for x in vals if x>0);loss=-sum(x for x in vals if x<0)
        dd=0;peak=0;equity=0
        for x in sorted(resolved,key=lambda y:(y['known'],y['id'])):
            equity+=x['r'];peak=max(peak,equity);dd=max(dd,peak-equity)
        stats[route]={'ideas':len(cur),'resolved_model':len(vals),
            'outcomes':dict(Counter(x['status'] for x in cur)),
            'net_R_sum_independent':round(sum(vals),4),
            'mean_R_resolved_independent':round(sum(vals)/len(vals),4) if vals else None,
            'PF_independent':round(gain/loss,4) if loss else None,
            'max_cumulative_R_drawdown_independent_not_portfolio':round(dd,4) if vals else None,
            'portfolio_max_dd':None,
            'warning':'Potentially simultaneous ideas; candle-touch fill model, no order ack, no portfolio.'}
    return stats

def regime(row):
    c=row.get('global_context_at_signal',{})
    v=c.get('btc_5d_ret_pct')
    if v is None:return 'BTC_5D_UNKNOWN'
    if v>=2:return 'BTC_UP_5D_2PCT'
    if v<=-2:return 'BTC_DOWN_5D_2PCT'
    return 'BTC_5D_RANGE_LT2PCT'

def run(data_dir='data/history',out='results_03/multicoin',end=DEFAULT_END,symbols=SYMBOLS):
    root=Path(out);root.mkdir(parents=True,exist_ok=True)
    check=audit(data_dir,end,symbols)
    (root/'history_audit.json').write_text(json.dumps(check,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    if check['status']!='READY_FOR_RESEARCH':
        result={'algorithm':ALGO,'status':'BLOCKED_HISTORY','errors':check['errors'],
                'backtest_completed':False,'no_fabricated_returns':True}
        (root/'SUMMARY.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        return result
    market={}
    for sym in symbols:
        one={}
        for tf in ('15m','1d'):
            bars,sha=load_csv(Path(data_dir)/f'{sym}_{tf}.csv',sym,tf)
            one[tf]=bars;one[tf+'_sha256']=sha
        market[sym]=one
    full={}
    for policy in FTA:
        for scenario,fee,slippage in COSTS:
            key=policy+'__'+scenario
            section={'policy':policy,'cost_model':{'fee':fee,'slippage':slippage},'symbols':{},'phases':{},'regimes':{},'ALL_SYMBOLS_INDEPENDENT':None}
            allrows=[]
            for sym in symbols:
                data=market[sym]
                calc=route_replay(data['15m'],sym,native={'1d':data['1d']},fta_policy=policy,fee=fee,slippage=slippage)
                rows=calc['qualified_ideas']
                enrich(rows,sym,data['1d'],market['BTCUSDT']['1d'] if 'BTCUSDT' in market else [],market['ETHUSDT']['1d'] if 'ETHUSDT' in market else [])
                for x in rows:x['symbol']=sym
                section['symbols'][sym]={'data_sha256':{'15m':data['15m_sha256'],'1d':data['1d_sha256']},
                                          'readiness':calc['readiness'],'routes':cohort(rows),'diagnostics':calc['diagnostics']}
                allrows.extend(rows)
                output=root/key;output.mkdir(parents=True,exist_ok=True)
                (output/(sym+'_ideas.jsonl')).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
            section['ALL_SYMBOLS_INDEPENDENT']=cohort(allrows)
            for name,a,b in PHASES:
                chosen=[x for x in allrows if ms(a)<=x['known']<ms(b)]
                section['phases'][name]=cohort(chosen)
            for state in ('BTC_UP_5D_2PCT','BTC_DOWN_5D_2PCT','BTC_5D_RANGE_LT2PCT','BTC_5D_UNKNOWN'):
                section['regimes'][state]=cohort([x for x in allrows if regime(x)==state])
            full[key]=section
    result={'algorithm':ALGO,'status':'RESEARCH_REPLAY_DONE_NOT_VALIDATED',
        'no_untouched_oos':True,'course_visual_labels_verified':0,
        'portfolio_backtest_done':False,'execution_order_ack':False,
        'scenario_grid':'Fixed upfront: 2 FTA policies x 2 cost assumptions; no post hoc selection',
        'cost_explainer':'Per-side fee/slippage are study assumptions, not account-specific tariffs.',
        'regime_method':'BTC 5-day closed daily return: >=2%, <=-2%, else range; descriptive, not trained/entry filter.',
        'universe':symbols,'coverage_end':end,'results':full}
    (root/'SUMMARY.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',default='data/history');p.add_argument('--out',default='results_03/multicoin')
    p.add_argument('--end',default=DEFAULT_END)
    a=p.parse_args();r=run(a.data_dir,a.out,a.end)
    print(r['status'])
    if r['status']=='BLOCKED_HISTORY':sys.exit(2)
if __name__=='__main__':main()
