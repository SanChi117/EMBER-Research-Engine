#!/usr/bin/env python3
"""Prove frozen MTF 0.3 trading engine bytes were not touched by audit additions."""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
EXPECTED='3d430361a7654b460281e76b1cb976c2a89676388a5adeb752049550992e6d46'

def check(path):
    actual=hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return {'status':'PASS_CORE_UNCHANGED' if actual==EXPECTED else 'FAIL_CORE_MUTATED',
            'core_sha256':actual,'frozen_sha256':EXPECTED,'trading_logic_modified':actual!=EXPECTED}

def main():
    p=argparse.ArgumentParser();p.add_argument('--core',default='src/mtf_engine.py');p.add_argument('--out',default='results_03/CORE_LOCK.json')
    a=p.parse_args();r=check(a.core);q=Path(a.out);q.parent.mkdir(parents=True,exist_ok=True)
    q.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(r['status'])
    sys.exit(0 if r['status']=='PASS_CORE_UNCHANGED' else 2)
if __name__=='__main__':main()
