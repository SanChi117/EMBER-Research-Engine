#!/usr/bin/env python3
"""READ-ONLY historical Binance USDT-M 15m/1d downloader. No keys/orders.
Not executed successfully in restricted offline environment, needs network at runtime.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,time,urllib.error,urllib.parse,urllib.request
from datetime import datetime,timezone
from pathlib import Path
from mtf_engine import ms,STEPS,iso
ENDPOINT='https://fapi.binance.com/fapi/v1/klines'
HEADER=['open_time','open','high','low','close','volume','close_time','quote_volume','trades','taker_buy_base_volume','taker_buy_quote_volume','symbol']

def read_json(url,retry=3):
    for i in range(retry):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MTF-EDUCATIONAL-BACKTEST/0.1'}),timeout=30) as f:
                return json.load(f)
        except (urllib.error.URLError,TimeoutError,ValueError) as e:
            if i==retry-1:raise RuntimeError('Public history unavailable; no synthetic replacement: '+str(e)) from e
            time.sleep(1.5**i)

def pull(symbol,tf,start,end,get=read_json,rate_sleep=0.12):
    if tf not in ('15m','1d','1w'):raise ValueError('TF forbidden')
    if not symbol.endswith('USDT'):raise ValueError('Require USDT symbol')
    if start>=end:raise ValueError('start >= end')
    step=STEPS[tf];cursor=start;all_rows=[]
    while cursor+step<=end:
        query=urllib.parse.urlencode({'symbol':symbol,'interval':tf,'startTime':cursor,'endTime':end-1,'limit':1500})
        raw=get(ENDPOINT+'?'+query)
        if not isinstance(raw,list):raise RuntimeError('Exchange returned non-list')
        if not raw:break
        new=[]
        for v in raw:
            if not isinstance(v,list) or len(v)<12:raise RuntimeError('Malformed candle')
            t=int(v[0]);
            if t+step>end:continue
            if all_rows and t<=int(all_rows[-1][0]):continue
            new.append([*v[:11],symbol]);
        if not new:break
        if all_rows and int(new[0][0])-int(all_rows[-1][0])!=step:raise RuntimeError('Historical gap '+symbol+' '+tf+' at '+str(cursor))
        all_rows.extend(new)
        new_cursor=int(new[-1][0])+step
        if new_cursor<=cursor:raise RuntimeError('No progress')
        cursor=new_cursor
        if rate_sleep:time.sleep(rate_sleep)
    if not all_rows:raise RuntimeError('No candles in requested interval for '+symbol+' '+tf)
    for left,right in zip(all_rows,all_rows[1:]):
        if int(right[0])-int(left[0])!=step:raise RuntimeError('Gap in '+symbol+' '+tf)
    return all_rows

def save(rows,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f);w.writerow(HEADER);w.writerows(rows)
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--symbols',default='BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BCHUSDT')
    p.add_argument('--start-15m',default='2026-04-01T00:00:00Z')
    p.add_argument('--start-1d',default='2024-01-01T00:00:00Z')
    p.add_argument('--end',default='2026-10-13T16:00:00Z')
    p.add_argument('--out',default='data/history')
    args=p.parse_args();symbols=list(dict.fromkeys(x.strip().upper() for x in args.symbols.split(',') if x.strip()))
    if any(x in ('DOTUSDT','PENDLEUSDT') for x in symbols):raise ValueError('User-excluded symbols')
    out=Path(args.out);records=[];end=ms(args.end)
    for symbol in symbols:
        for tf,start in [('15m',args.start_15m),('1d',args.start_1d)]:
            print('Downloading',symbol,tf,flush=True)
            rows=pull(symbol,tf,ms(start),end)
            path=out/(symbol+'_'+tf+'.csv');digest=save(rows,path)
            records.append({'symbol':symbol,'tf':tf,'rows':len(rows),'first':iso(int(rows[0][0])),'last':iso(int(rows[-1][0])),'sha256':digest,'file':path.name})
    out.mkdir(parents=True,exist_ok=True)
    (out/'manifest.json').write_text(json.dumps({'origin':ENDPOINT,'end_cutoff':args.end,'data':records},ensure_ascii=False,indent=2),encoding='utf-8')
    print('DONE, independent data manifests saved; no orders sent.')
if __name__=='__main__':main()
