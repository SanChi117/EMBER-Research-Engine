#!/usr/bin/env python3
"""Reproducible research cohort report by signal timestamp; not a portfolio backtest."""
import argparse,csv,hashlib,json,sys
from collections import Counter
from pathlib import Path
from mtf_engine import load_csv,route_replay,ms,ALGO,iso
from global_context import enrich

def cohort(rows):
    buckets={}
    for route in ('A_VC_IMB_SNR','B_IDM','C_BOS_15M_PROXY'):
        a=[x for x in rows if x['route']==route]
        settled=[x['r'] for x in a if x.get('r') is not None]
        gain=sum(v for v in settled if v>0);loss=-sum(v for v in settled if v<0)
        buckets[route]={'ideas':len(a),'resolved':len(settled),'status':dict(Counter(x['status'] for x in a)),
                        'profit_factor_independent':round(gain/loss,3) if loss else None,
                        'mean_R_resolved':round(sum(settled)/len(settled),4) if settled else None,
                        'total_R_independent':round(sum(settled),4),'note':'overlapping ideas; not a real equity curve'}
    return buckets

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',default='data/history');p.add_argument('--out',default='results_90d')
    p.add_argument('--symbols',default='BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BCHUSDT')
    p.add_argument('--test-from',default='2026-07-15T00:00:00Z');p.add_argument('--test-until',default='2026-10-13T16:00:00Z')
    p.add_argument('--min-rr',type=float,default=2.0)
    p.add_argument('--fta-policy',choices=['COURSE_PARENT_FTA','V22_FIRST_OBSTACLE'],default='COURSE_PARENT_FTA')
    args=p.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    lower=ms(args.test_from);upper=ms(args.test_until)
    if not lower<upper:raise ValueError('Invalid OOS window')
    allstats={}
    btc_ref=Path(args.data_dir)/'BTCUSDT_1d.csv'
    eth_ref=Path(args.data_dir)/'ETHUSDT_1d.csv'
    btc_day=load_csv(btc_ref,'BTCUSDT','1d')[0] if btc_ref.exists() else []
    eth_day=load_csv(eth_ref,'ETHUSDT','1d')[0] if eth_ref.exists() else []
    for symbol in args.symbols.upper().split(','):
        f=Path(args.data_dir)/(symbol+'_15m.csv');daily=Path(args.data_dir)/(symbol+'_1d.csv')
        bars,h=load_csv(f,symbol);d,h2=load_csv(daily,symbol,'1d')
        bars=[z for z in bars if z.end<=upper]
        if not bars or bars[-1].end<upper:raise RuntimeError('Insufficient 15m coverage '+symbol)
        result=route_replay(bars,symbol,min_rr=args.min_rr,native={'1d':d},strict_daily=True,fta_policy=args.fta_policy)
        enrich(result['qualified_ideas'],symbol,d,btc_day,eth_day)
        if not all(result['readiness'][k] for k in ('history_1d_ge_50','history_1w_ge_10','complete_90d_15m')):
            raise RuntimeError('Invalid history length '+symbol+' '+repr(result['readiness']))
        test=[x for x in result['qualified_ideas'] if lower<=ms(x['at'])<upper]
        train=[x for x in result['qualified_ideas'] if ms(x['at'])<lower]
        summary={'symbol':symbol,'algorithm':ALGO,'fta_policy':args.fta_policy,'data':{'15m':h,'1d':h2},'train':cohort(train),'evaluation_90d_NOT_UNTOUCHED':cohort(test),
                 'note':'This is a cohort split for a pre-fixed model. Not independent OOS if settings were chosen using test data. No real fills.'}
        allstats[symbol]=summary
        (out/(symbol+'_cohorts.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        (out/(symbol+'_ideas.jsonl')).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in result['qualified_ideas']),encoding='utf-8')
        print(symbol,'OOS ideas',sum(v['ideas'] for v in summary['evaluation_90d_NOT_UNTOUCHED'].values()),flush=True)
    (out/'SUMMARY.json').write_text(json.dumps({'algorithm':ALGO,'test_from':args.test_from,'test_until':args.test_until,'risk_accounting':'NOT PORTFOLIO','symbols':allstats},ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':main()
