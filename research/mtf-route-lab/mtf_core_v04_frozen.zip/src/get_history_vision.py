#!/usr/bin/env python3
"""Verified public Binance Vision USD-M Futures monthly/daily archive importer.

Designed for environments where Binance REST /fapi/v1/klines is geo-blocked.
Reads market data only; does not contact private account or send orders.
Historical completeness is mandatory. Checks official companion SHA256 sums.
"""
from __future__ import annotations
import argparse,csv,hashlib,io,json,urllib.error,urllib.request,zipfile
from datetime import datetime,timezone,timedelta
from pathlib import Path
from get_history import HEADER,save
from mtf_engine import ms,STEPS,iso
BASE='https://data.binance.vision/data/futures/um'
TF_ALLOWED=('15m','1d')

def fetch_raw(url):
    req=urllib.request.Request(url,headers={'User-Agent':'MTF_ROUTE_LAB_0.2/ARCHIVE_VERIFIER'})
    with urllib.request.urlopen(req,timeout=55) as r:return r.read()

def parse_zip(blob,expected_filename):
    with zipfile.ZipFile(io.BytesIO(blob)) as f:
        csvfiles=[x for x in f.namelist() if x.endswith('.csv')]
        if len(csvfiles)!=1:raise ValueError('Archive must contain exactly one CSV '+expected_filename)
        csv_data=f.read(csvfiles[0]).decode('utf-8-sig')
    rows=[]
    for line in csv.reader(io.StringIO(csv_data)):
        if not line or line[0].lower() in ('open_time','open time'):continue
        if len(line)<11:raise ValueError('Invalid Binance klines CSV row')
        values=line[:11]
        t=int(values[0]);close=int(values[6]);
        if t>10**14:t//=1000
        elif t<10**11:t*=1000
        if close>10**14:close//=1000
        elif close<10**11:close*=1000
        values[0]=str(t);values[6]=str(close)
        rows.append(values)
    return rows

def archive(symbol,tf,yyyymm,fetch=fetch_raw,daily=None):
    if tf not in TF_ALLOWED:raise ValueError('bad timeframe')
    if daily:
        fname=f'{symbol}-{tf}-{daily}.zip'
        url=f'{BASE}/daily/klines/{symbol}/{tf}/{fname}'
    else:
        fname=f'{symbol}-{tf}-{yyyymm}.zip'
        url=f'{BASE}/monthly/klines/{symbol}/{tf}/{fname}'
    blob=fetch(url)
    cs=fetch(url+'.CHECKSUM').decode('utf-8').strip()
    expected=cs.split()[0].lower()
    actual=hashlib.sha256(blob).hexdigest()
    if expected!=actual:raise ValueError('Binance Vision archive checksum mismatch '+fname)
    return parse_zip(blob,fname),{'url':url,'sha256':actual,'rows':None}

def month_start(dt):return dt.replace(day=1,hour=0,minute=0,second=0,microsecond=0)

def next_month(dt):return month_start(dt.replace(day=28)+timedelta(days=4))

def pull(symbol,tf,start,end,fetch=fetch_raw):
    if tf not in TF_ALLOWED or not symbol.endswith('USDT'):raise ValueError('bad market/tf')
    if end<=start:raise ValueError('bad UTC interval')
    left=datetime.fromtimestamp(start/1000,timezone.utc);right=datetime.fromtimestamp((end-1)/1000,timezone.utc)
    now=datetime.now(timezone.utc);cur=month_start(left);cache=[];sources=[]
    while cur<=right:
        month_end=next_month(cur)
        label=cur.strftime('%Y-%m');monthly_published=month_end+timedelta(days=6)<now
        if monthly_published:
            try:
                rr,src=archive(symbol,tf,label,fetch)
                src['rows']=len(rr);cache+=rr;sources.append(src)
                cur=month_end;continue
            except urllib.error.HTTPError as e:
                if e.code!=404:raise
        # A month archive isn't ready: fetch daily complete UTC archives.
        day=max(cur,datetime(left.year,left.month,left.day,tzinfo=timezone.utc))
        while day<month_end and day<=right:
            if day+timedelta(days=1)>now:
                raise RuntimeError('UTC day archive not yet complete; REST backfill required '+day.isoformat())
            rr,src=archive(symbol,tf,label,fetch,daily=day.strftime('%Y-%m-%d'))
            src['rows']=len(rr);cache+=rr;sources.append(src)
            day+=timedelta(days=1)
        cur=month_end
    rows=sorted(([*v,symbol] for v in cache if start<=int(v[0]) and int(v[0])+STEPS[tf]<=end),key=lambda z:int(z[0]))
    if not rows:raise RuntimeError('No complete market history')
    expected_first=((start+STEPS[tf]-1)//STEPS[tf])*STEPS[tf]
    # UTC 1w is Monday aligned, but we only fetch 1d/15m.
    if int(rows[0][0])!=expected_first:raise RuntimeError('Missing initial candle '+symbol+' '+tf+' '+iso(expected_first))
    for a,b in zip(rows,rows[1:]):
        if int(b[0])-int(a[0])!=STEPS[tf]:raise RuntimeError('Missing/duplicate candle at '+str(a[0]))
    if int(rows[-1][0])+STEPS[tf]<end:raise RuntimeError('Missing final candle '+symbol+' '+tf)
    return rows,sources

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--symbols',default='BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BCHUSDT')
    p.add_argument('--start-15m',default='2026-04-01T00:00:00Z')
    p.add_argument('--start-1d',default='2024-01-01T00:00:00Z')
    p.add_argument('--end',default='2026-10-13T00:00:00Z',help='UTC midnight boundary for archived daily files; latest day may not be published')
    p.add_argument('--out',default='data/history')
    a=p.parse_args();end=ms(a.end);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);manifest=[]
    for symbol in a.symbols.upper().split(','):
        for tf,st in [('15m',a.start_15m),('1d',a.start_1d)]:
            rows,sources=pull(symbol,tf,ms(st),end)
            digest=save(rows,out/(symbol+'_'+tf+'.csv'))
            manifest.append({'symbol':symbol,'tf':tf,'candles':len(rows),'sha256':digest,'sources':sources})
            print(symbol,tf,'verified',len(rows),'bars',flush=True)
    (out/'manifest_vision.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':main()
