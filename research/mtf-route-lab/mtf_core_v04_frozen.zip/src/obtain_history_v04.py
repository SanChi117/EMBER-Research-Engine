#!/usr/bin/env python3
"""Transactional, non-trading Binance USD-M history intake.

No mixing Vision and REST into a single ten-file dataset; complete validation
must pass in separate stage before promotion. Protects the old working corpus.
No API credentials and NO order APIs.
"""
from __future__ import annotations
import argparse,json,shutil,subprocess,sys,tempfile
from datetime import datetime,timezone
from pathlib import Path
from history_gate_v04 import audit_strict
from validate_history_v03 import DEFAULT_END


def obtain(data_dir='data/history',end=DEFAULT_END,out='results_04/DOWNLOAD_ATTEMPT.json',download=False):
    target=Path(data_dir).resolve();report=Path(out)
    check=audit_strict(target,end)
    result={'status':'READY_FOR_RESEARCH' if check['status']=='READY_FOR_RESEARCH' else 'BLOCKED_HISTORY',
            'mode':'download' if download else 'check_only',
            'active_directory':str(target),'reused_existing':check['status']=='READY_FOR_RESEARCH',
            'old_directory_overwritten':False, 'source':check['source_manifest_type'], 'attempts':[]}
    if check['status']=='READY_FOR_RESEARCH':
        pass
    elif download:
        target.parent.mkdir(parents=True,exist_ok=True)
        parent=Path(__file__).resolve().parent
        for source,program in [('VISION','get_history_vision.py'),('REST','get_history.py')]:
            stage=Path(tempfile.mkdtemp(prefix='.mtf_usdm_'+source.lower()+'_',dir=target.parent))
            cmd=[sys.executable,str(parent/program),'--end',end,'--out',str(stage)]
            try:
                proc=subprocess.run(cmd,capture_output=True,text=True,timeout=1200)
                attempt={'method':source,'exit_code':proc.returncode,'staging_verified':False,
                         'output_tail':(proc.stdout+'\n'+proc.stderr)[-1200:]}
                if proc.returncode==0:
                    trial=audit_strict(stage,end)
                    attempt['staging_verified']=trial['status']=='READY_FOR_RESEARCH'
                    attempt['validation_errors']=trial['errors'][:20]
                    if attempt['staging_verified']:
                        # Preserve old data as a dated backup, no mixing across
                        # distinct source manifests or partial failed downloads.
                        if target.exists():
                            time_tag=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
                            backup=target.parent/(target.name+'_previous_'+time_tag)
                            if backup.exists():raise RuntimeError('Backup naming conflict')
                            target.rename(backup)
                            result['previous_directory_saved_as']=str(backup)
                        stage.rename(target)
                        result.update(status='READY_FOR_RESEARCH',source=source,reused_existing=False)
                        result['attempts'].append(attempt)
                        break
                result['attempts'].append(attempt)
            except subprocess.TimeoutExpired:
                result['attempts'].append({'method':source,'status':'TIMEOUT','seconds':1200})
            finally:
                if stage.exists():shutil.rmtree(stage)
    report.parent.mkdir(exist_ok=True,parents=True)
    report.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',default='data/history')
    p.add_argument('--end',default=DEFAULT_END)
    p.add_argument('--out',default='results_04/DOWNLOAD_ATTEMPT.json')
    p.add_argument('--download',action='store_true',help='attempt verified download with staging; without flag no network')
    a=p.parse_args();r=obtain(a.data_dir,a.end,a.out,a.download)
    print(r['status'],'mode',r['mode'],'source',r['source'])
    return 0 if r['status']=='READY_FOR_RESEARCH' else 2
if __name__=='__main__':sys.exit(main())
