#!/usr/bin/env python3
"""Chronological portfolio *model* for frozen MTF v0.3 ideas; no orders/API.

Research-only accounting companion. It reads approved signals, never invents or
filters a new entry model. Resolves OHLC ambiguity against the model. Assumptions
are explicit: filled limit on touch is NOT guaranteed on an exchange; equity is
based on closed trades, and open-position unrealised losses are not in drawdown.
"""
from __future__ import annotations
import argparse, json, math, hashlib
from collections import Counter, defaultdict
from pathlib import Path
from mtf_engine import Bar, ms, iso, load_csv, route_replay, ALGO

RESOLUTION=('TP','SL','SL_FIRST_AMBIGUOUS','TIME_EXIT')


def portfolio(bars_by_symbol, ideas, *, policy=None, initial_equity=1000.,
              risk_fraction=.005, fee=.0005, slippage=.0002,
              max_concurrent=2, max_gross_leverage=3., order_bars=12,
              hold_bars=96):
    if initial_equity<=0 or not 0<risk_fraction<=.1 or min(max_concurrent,order_bars,hold_bars)<=0:
        raise ValueError('invalid research parameters')
    if not 0<=fee<.1 or not 0<=slippage<.1 or not 0<max_gross_leverage<=10:
        raise ValueError('invalid cost/leverage parameters')
    if not bars_by_symbol:raise ValueError('no market data')
    steps=set()
    end_by_symbol={}
    by_end=defaultdict(list)
    for sym,bars in bars_by_symbol.items():
        if not bars:raise ValueError('empty data '+sym)
        for a,b in zip(bars,bars[1:]):
            if a.end!=b.start:raise ValueError('broken 15m continuity '+sym)
        end_by_symbol[sym]=bars[-1].end
        for b in bars:
            if b.tf!='15m':raise ValueError('requires 15m OHLC')
            by_end[b.end].append((sym,b))
            steps.add(b.end)
    signal_by_time=defaultdict(list); seen_ids=set()
    for item in ideas:
        row=dict(item);uid=row['id']
        if uid in seen_ids:raise ValueError('duplicate signal id '+uid)
        seen_ids.add(uid)
        if policy is not None and str(row.get('note','')).split(';')[0]!=policy:
            raise ValueError('FTA policy mismatch: '+uid)
        sym=row['symbol']
        if sym not in bars_by_symbol:raise ValueError('no 15m candles for '+sym)
        if row['side'] not in ('LONG','SHORT'):raise ValueError('bad side')
        entry,stop,target=map(float,(row['entry'],row['stop'],row['target']))
        if not all(math.isfinite(x) and x>0 for x in (entry,stop,target)):
            raise ValueError('nonfinite prices')
        if not ((stop<entry<target) if row['side']=='LONG' else (target<entry<stop)):
            raise ValueError('invalid entry-stop-target geometry')
        known=int(row['known'])
        if known not in steps or not any(s==sym for s,_ in by_end[known]):
            raise ValueError('signal not at closed candle for symbol '+uid)
        signal_by_time[known].append(row)
    pending={};positions={};equity=float(initial_equity);peak=equity;max_dd=0.
    events=[];completed=[];rejections=Counter();equity_curve=[]
    last_prices={};mtm_peak=initial_equity;mtm_max_dd=0.;mtm_last=initial_equity
    def emit(now,kind,sym,row,**extra):
        events.append({'at':iso(now),'kind':kind,'symbol':sym,'id':row['id'],**extra})
    def active_gross():
        return sum(p['qty']*p['entry'] for p in positions.values())
    for now in sorted(steps):
        candles=dict(by_end[now]);
        for sym,b in candles.items():last_prices[sym]=b.c
        # First settle existing positions, then existing orders; same-candle
        # stop/target on a position is resolved in favour of the stop.
        for sym in sorted(set(positions)&set(candles)):
            p=positions[sym];b=candles[sym];row=p['idea'];L=row['side']=='LONG'
            stop=p['stop'];target=p['target'];s=b.l<=stop if L else b.h>=stop
            t=b.h>=target if L else b.l<=target
            status=None;exit_price=None
            if s:
                status='SL_FIRST_AMBIGUOUS' if t else 'SL'
                exit_price=min(b.o,stop) if L else max(b.o,stop)
            elif t:
                status='TP';exit_price=target
            elif p['age']+1>=hold_bars:
                status='TIME_EXIT';exit_price=b.c
            if status is None:
                p['age']+=1
                continue
            directional=(exit_price-p['entry']) if L else (p['entry']-exit_price)
            pnl=p['qty']*(directional-(fee+slippage)*(p['entry']+exit_price))
            equity+=pnl;peak=max(peak,equity);max_dd=max(max_dd,1-equity/peak)
            trade={'id':row['id'],'symbol':sym,'route':row['route'],'signal_at':iso(row['known']),
                   'fill_at':p['fill_at'],'exit_at':iso(now),'status':status,
                   'entry':p['entry'],'exit_price':exit_price,'stop':stop,'target':target,
                   'qty':p['qty'],'pnl_quote':round(pnl,8),'r_on_planned_risk':round(pnl/p['risk_quote'],8),
                   'equity_after':round(equity,8),'model_touch_only':True}
            completed.append(trade);emit(now,'MODEL_EXIT',sym,row,status=status,pnl_quote=round(pnl,8))
            del positions[sym]
        # Pending orders can only begin on bars AFTER the signal's candle.
        for sym in sorted(set(pending)&set(candles)):
            p=pending[sym];b=candles[sym];row=p['idea'];L=row['side']=='LONG'
            E=p['entry'];S=p['stop'];T=p['target']
            reaches_target=b.h>=T if L else b.l<=T
            touches=b.l<=E if L else b.h>=E
            passes_stop=b.l<=S if L else b.h>=S
            gap_bad=b.o<S if L else b.o>S
            age=p['age']+1
            if (reaches_target and not touches) or (reaches_target and touches):
                emit(now,'CANCELLED_PRICE_PATH_UNKNOWN' if touches else 'CANCELLED_TARGET_BEFORE_FILL',sym,row)
                rejections['TARGET_BEFORE_FILL_UNCLEAR_PATH' if touches else 'TARGET_BEFORE_FILL']+=1
                del pending[sym];continue
            if passes_stop and not touches:
                emit(now,'CANCELLED_INVALIDATED_BEFORE_FILL',sym,row)
                rejections['INVALIDATED_BEFORE_FILL']+=1;del pending[sym];continue
            if touches:
                if gap_bad:
                    emit(now,'CANCELLED_GAP_BEYOND_STOP',sym,row)
                    rejections['GAP_BEYOND_STOP']+=1;del pending[sym];continue
                if len(positions)>=max_concurrent:
                    emit(now,'REJECTED_AT_FILL_CAPACITY',sym,row);rejections['CAPACITY']+=1
                    del pending[sym];continue
                # Risk sizing after all prior closed exits, never using future PnL.
                one_unit_loss=abs(E-S)+(fee+slippage)*(E+S)
                wanted_risk=max(0.,equity*risk_fraction)
                remaining_gross=max(0.,equity*max_gross_leverage-active_gross())
                qty=min(wanted_risk/one_unit_loss,remaining_gross/E) if one_unit_loss>0 else 0
                if qty<=0 or equity<=0:
                    emit(now,'REJECTED_AT_FILL_EXPOSURE',sym,row)
                    rejections['EXPOSURE']+=1;del pending[sym];continue
                p.update({'qty':qty,'risk_quote':qty*one_unit_loss,'fill_at':iso(b.start),'age':1})
                positions[sym]=p;emit(now,'MODEL_LIMIT_TOUCH_NOT_EXCHANGE_ACK',sym,row,
                                      qty=round(qty,10),risk_quote=round(p['risk_quote'],8))
                del pending[sym]
                # A filled trade may already hit SL/TP on this very bar. OHLC
                # has no intrabar order: count stop first, don't credit TP.
                s=b.l<=S if L else b.h>=S
                t=b.h>=T if L else b.l<=T
                if s or hold_bars==1:
                    exec_stop=(min(b.o,S) if L else max(b.o,S)) if s else b.c
                    pnl=qty*((exec_stop-E if L else E-exec_stop)-(fee+slippage)*(E+exec_stop))
                    equity+=pnl;peak=max(peak,equity);max_dd=max(max_dd,1-equity/peak)
                    status=('SL_FIRST_AMBIGUOUS' if t else 'SL') if s else 'TIME_EXIT'
                    completed.append({'id':row['id'],'symbol':sym,'route':row['route'],'signal_at':iso(row['known']),
                      'fill_at':p['fill_at'],'exit_at':iso(now),'status':status,'entry':E,'exit_price':exec_stop,
                      'stop':S,'target':T,'qty':qty,'pnl_quote':round(pnl,8),
                      'r_on_planned_risk':round(pnl/p['risk_quote'],8),'equity_after':round(equity,8),'model_touch_only':True})
                    emit(now,'MODEL_EXIT',sym,row,status=status,pnl_quote=round(pnl,8))
                    del positions[sym]
                continue
            if age>=order_bars:
                emit(now,'MODEL_ORDER_EXPIRED',sym,row)
                rejections['EXPIRED_NO_FILL']+=1;del pending[sym]
            else:p['age']=age
        # Decisions only at close of current bar. Different routes do not
        # become additional independent positions for the same symbol.
        for row in sorted(signal_by_time.get(now,()),key=lambda x:(x['symbol'],x['id'])):
            sym=row['symbol'];
            if sym in pending or sym in positions:
                rejections['BUSY_SYMBOL']+=1;emit(now,'IDEA_DECLINED_BUSY_SYMBOL',sym,row);continue
            pending[sym]={'idea':row,'entry':float(row['entry']),'stop':float(row['stop']),
                          'target':float(row['target']),'age':0}
            emit(now,'MODEL_ORDER_PLACED_AFTER_CLOSED_SIGNAL',sym,row)
        mtm=equity
        for sym,p in positions.items():
            mark=last_prices[sym];E=p['entry'];q=p['qty'];L=p['idea']['side']=='LONG'
            mtm+=q*((mark-E if L else E-mark)-(fee+slippage)*(E+mark))
        mtm_last=mtm;mtm_peak=max(mtm_peak,mtm);mtm_max_dd=max(mtm_max_dd,1-mtm/mtm_peak)
        equity_curve.append({'at':iso(now),'closed_equity':round(equity,8),
                             'mtm_close_equity_estimate':round(mtm,8),
                             'open_positions':len(positions),'pending':len(pending)})
    # Always distinguish unresolved from NO_FILL or filled completed PnL.
    for sym,p in pending.items():
        emit(end_by_symbol[sym],'PENDING_AT_DATA_END',sym,p['idea']);rejections['PENDING_UNRESOLVED']+=1
    for sym,p in positions.items():
        emit(end_by_symbol[sym],'OPEN_CENSORED_AT_DATA_END',sym,p['idea']);rejections['OPEN_CENSORED']+=1
    wins=sum(t['pnl_quote'] for t in completed if t['pnl_quote']>0)
    losses=-sum(t['pnl_quote'] for t in completed if t['pnl_quote']<0)
    summary={'status':'PAPER_MODEL_NOT_EXCHANGE_FILLS','initial_equity':initial_equity,
      'final_closed_equity':round(equity,8),'closed_equity_return_pct':round(100*(equity/initial_equity-1),6),
      'max_closed_equity_drawdown_pct_NOT_MTM':round(max_dd*100,6),
      'max_bar_close_MTM_drawdown_pct':round(mtm_max_dd*100,6),
      'ending_bar_close_MTM_equity':round(mtm_last,8),
      'ending_unrealized_quote_estimate':round(mtm_last-equity,8),
      'completed_model_trades':len(completed),
      'win_rate_resolved':round(sum(x['pnl_quote']>0 for x in completed)/len(completed),5) if completed else None,
      'PF_resolved':round(wins/losses,5) if losses else None,
      'net_pnl':round(sum(x['pnl_quote'] for x in completed),8),
      'routes_completed':dict(Counter(x['route'] for x in completed)),
      'rejections':dict(rejections),'ending_open_positions':len(positions),'ending_pending_orders':len(pending),
      'limits':{'risk_fraction':risk_fraction,'max_concurrent':max_concurrent,'max_gross_leverage':max_gross_leverage,
                'order_life_15m_bars':order_bars,'max_hold_15m_bars':hold_bars,
                'fee_per_side':fee,'slippage_per_side':slippage},
      'disclaimers':['OHLC touch is not exchange order-book fill or order acknowledgment',
                     'No mark-price liquidation, tick/lot rounding, funding or partial fills',
                     'Bar-close mark-to-market estimate misses intrabar equity lows and liquidation risk',
                     'No real spread samples; slippage is a frozen research assumption',
                     'No strategy parameter tuning; idea inputs from v0.3 are unchanged']}
    return {'summary':summary,'trades':completed,'ledger':sorted(events,key=lambda x:(ms(x['at']),x['kind'],x['id'])),
            'closed_equity_curve':equity_curve}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data-dir',default='data')
    ap.add_argument('--policy',choices=['COURSE_PARENT_FTA','V22_FIRST_OBSTACLE'],default='COURSE_PARENT_FTA')
    ap.add_argument('--sample',action='store_true',help='use archived 1000x15m BTC fixture, NOT a long backtest')
    ap.add_argument('--out',default='results_portfolio_proxy');ap.add_argument('--fee',type=float,default=.0005)
    ap.add_argument('--slippage',type=float,default=.0002)
    args=ap.parse_args()
    if not args.sample:raise SystemExit('Supply validated long history via dedicated run_research first; --sample is the short fixture ONLY')
    bars,bar_sha=load_csv(Path(args.data_dir)/'BTCUSDT_15m_KIMI_1000.csv','BTCUSDT','15m')
    daily,day_sha=load_csv(Path(args.data_dir)/'BTCUSDT_1d_KIMI_60.csv','BTCUSDT','1d')
    fresh=route_replay(bars,'BTCUSDT',native={'1d':daily},fta_policy=args.policy,fee=args.fee,slippage=args.slippage)
    if fresh['algorithm']!=ALGO:raise RuntimeError('engine version mismatch')
    data=[{**row,'symbol':'BTCUSDT'} for row in fresh['qualified_ideas']]
    outcome=portfolio({'BTCUSDT':bars},data,policy=args.policy,fee=args.fee,slippage=args.slippage)
    dest=Path(args.out);dest.mkdir(parents=True,exist_ok=True)
    outcome['summary']['engine_version']=ALGO
    outcome['summary']['independent_idea_count']=len(data)
    outcome['summary']['data_sha256']={'15m':bar_sha,'1d':day_sha}
    (dest/'SUMMARY.json').write_text(json.dumps(outcome['summary'],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (dest/'FRESH_IDEAS.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in data),encoding='utf-8')
    (dest/'TRADES.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in outcome['trades']),encoding='utf-8')
    (dest/'LEDGER.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in outcome['ledger']),encoding='utf-8')
    (dest/'EQUITY_CLOSED.json').write_text(json.dumps(outcome['closed_equity_curve'],ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(outcome['summary'],ensure_ascii=False,indent=2))
if __name__=='__main__':main()
