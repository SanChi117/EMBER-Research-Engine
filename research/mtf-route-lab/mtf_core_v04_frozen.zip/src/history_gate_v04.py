#!/usr/bin/env python3
"""Read-only provenance and consistency gate for frozen MTF 0.3 research.

It does NOT claim local manifests cryptographically prove remote publisher identity.
Vision importer checks official zipped CHECKSUM at acquisition time. This gate
checks manifest structure, recorded per-package hashes, CSV hashes, 15m/1d
price AND volume continuity. REST importer remains an explicitly weaker source.
No orders, API keys or alterations to MTF entry conditions.
"""
from __future__ import annotations
import argparse, json, math, re, sys
from pathlib import Path
from mtf_engine import load_csv, iso
from validate_history_v03 import audit, SYMBOLS, DEFAULT_END
from source_fingerprint_v04 import classify

HEX = re.compile(r'^[0-9a-fA-F]{64}$')

def audit_strict(data_dir='data/history', end=DEFAULT_END, symbols=SYMBOLS):
    root = Path(data_dir)
    try:
        base = audit(root, end, symbols)
    except (ValueError, OSError, KeyError, TypeError) as ex:
        return {'status':'BLOCKED_HISTORY', 'research_gate_version':'PROVENANCE_QA_0.4',
                'source_manifest_type':'MALFORMED_OR_UNREADABLE', 'provenance_level':'NONE',
                'symbols':list(symbols), 'cross_checked_daily_volume_days':0,
                'errors':['BASE_HISTORY_AUDIT_FAILED '+type(ex).__name__+': '+str(ex)],
                'historical_data_audit':None, 'market_fingerprint_probes':{},
                'real_orders_enabled':False}
    issues = list(base['errors'])
    required = {(s, tf) for s in symbols for tf in ('15m', '1d')}
    manifest_type = base['source_manifest_type']
    # The old v0.3 gate incorrectly accepted a full, locally made CSV without
    # a provenance manifest. This v0.4 companion denies it.
    if manifest_type == 'NONE_NO_PROVENANCE':
        issues.append('UNVERIFIED_ORIGIN: no manifest_vision.json or manifest.json')
    elif manifest_type == 'VISION_SHA256':
        try:
            records = json.loads((root/'manifest_vision.json').read_text(encoding='utf-8'))
            if not isinstance(records, list):
                raise ValueError('manifest must be a list')
            seen = set()
            for rec in records:
                key = (rec['symbol'], rec['tf'])
                if key in seen:issues.append('DUPLICATE_SOURCE_MANIFEST '+str(key))
                seen.add(key)
                if key not in required:continue
                if not HEX.fullmatch(str(rec.get('sha256',''))):
                    issues.append('INVALID_LOCAL_SHA256 '+str(key))
                sources = rec.get('sources')
                if not isinstance(sources, list) or not sources:
                    issues.append('MISSING_OFFICIAL_ARCHIVE_SOURCES '+str(key))
                    continue
                sym, tf = key
                prefix = ('https://data.binance.vision/data/futures/um/')
                valid_parents = (f'{prefix}monthly/klines/{sym}/{tf}/{sym}-{tf}-',
                                 f'{prefix}daily/klines/{sym}/{tf}/{sym}-{tf}-')
                for source in sources:
                    if (not isinstance(source, dict)
                        or not str(source.get('url','')).startswith(valid_parents)
                        or not str(source.get('url','')).endswith('.zip')
                        or not HEX.fullmatch(str(source.get('sha256','')))
                        or not isinstance(source.get('rows'), int)
                        or source['rows'] <= 0):
                        issues.append('INVALID_VISION_SOURCE '+str(key))
                        break
            for key in sorted(required-seen):issues.append('MISSING_MANIFEST_RECORD '+str(key))
        except (OSError, ValueError, TypeError, KeyError) as ex:
            issues.append('MALFORMED_VISION_MANIFEST '+str(ex))
    elif manifest_type == 'REST_MANIFEST_LOCAL_SHA256':
        # Locally recorded REST page hashes can detect tampering but not
        # authenticate the origin without independently preserved HTTP proofs.
        try:
            records=json.loads((root/'manifest.json').read_text(encoding='utf-8'))['data']
            seen=set()
            for rec in records:
                key=(rec['symbol'],rec['tf'])
                if key in seen:issues.append('DUPLICATE_REST_RECORD '+str(key))
                seen.add(key)
                if key in required and (not HEX.fullmatch(str(rec.get('sha256','')))
                                        or rec.get('file')!=f'{key[0]}_{key[1]}.csv'):
                    issues.append('INVALID_REST_RECORD '+str(key))
            for key in sorted(required-seen):issues.append('MISSING_REST_RECORD '+str(key))
        except (OSError, ValueError, TypeError, KeyError) as ex:
            issues.append('MALFORMED_REST_MANIFEST '+str(ex))
    else:issues.append('UNSUPPORTED_PROVENANCE_TYPE '+str(manifest_type))

    volume_days_checked = 0
    market_probes = {}
    for symbol in symbols:
        # Price already cross-checked by v0.3; this checks *quantity*.
        if (base['symbols'].get(symbol,{}).get('15m',{}).get('status') != 'COMPLETE'
            or base['symbols'].get(symbol,{}).get('1d',{}).get('status') != 'COMPLETE'):
            continue
        quarters,_ = load_csv(root/f'{symbol}_15m.csv', symbol, '15m')
        days,_ = load_csv(root/f'{symbol}_1d.csv', symbol, '1d')
        native = {d.start:d for d in days}
        for tf,bars in [('15m',quarters),('1d',days)]:
            assessment = classify(symbol,tf,bars)
            market_probes[symbol+'_'+tf] = assessment
            if assessment['status'] in ('MATCHES_SPOT_NOT_FUTURES','DOES_NOT_MATCH_FUTURES_PROBE'):
                issues.append('FUTURES_MARKET_FINGERPRINT_MISMATCH '+symbol+' '+tf+' '+assessment['status'])
        for i in range(0,len(quarters),96):
            group=quarters[i:i+96]
            if len(group) != 96:break
            d=native[group[0].start]
            aggregate=sum(z.v for z in group)
            if not math.isclose(aggregate,d.v,rel_tol=1e-5,abs_tol=1e-6):
                issues.append(f'DAILY_VOLUME_MISMATCH {symbol} {iso(d.start)} 15m={aggregate:.12g} 1d={d.v:.12g}')
                break
            volume_days_checked += 1
    result = {
        'status':'READY_FOR_RESEARCH' if not issues else 'BLOCKED_HISTORY',
        'research_gate_version':'PROVENANCE_QA_0.4',
        'source_manifest_type':manifest_type,
        'provenance_level':('VISION_CHECKSUMS_RECORDED_NOT_REMOTE_ATTESTED' if manifest_type=='VISION_SHA256'
            else 'REST_URL_CLAIM_LOCAL_HASH_ONLY' if manifest_type=='REST_MANIFEST_LOCAL_SHA256'
            else 'NONE'),
        'symbols':list(symbols),
        'cross_checked_daily_volume_days':volume_days_checked,
        'market_fingerprint_probes':market_probes,
        'errors':issues,
        'historical_data_audit':base,
        'real_orders_enabled':False,
        'warning':'CSV plus JSON manifest do not independently attest the remote publisher; independent archived checksums require acquisition proof.',
    }
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',default='data/history')
    p.add_argument('--end',default=DEFAULT_END)
    p.add_argument('--symbols',default=','.join(SYMBOLS))
    p.add_argument('--out',default='results_04/HISTORY_GATE.json')
    a=p.parse_args()
    r=audit_strict(a.data_dir,a.end,tuple(a.symbols.split(',')))
    out=Path(a.out);out.parent.mkdir(exist_ok=True,parents=True)
    out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(r['status'],'source',r['source_manifest_type'],'volume days',r['cross_checked_daily_volume_days'],'errors',len(r['errors']))
    return 0 if r['status']=='READY_FOR_RESEARCH' else 2

if __name__=='__main__':sys.exit(main())
