#!/usr/bin/env python3
"""Strict point-in-time BTC/ETH/global-market annotations, never entry gates.
Only a full CLOSED UTC daily candle is visible to a signal. No inferred macro/OI.
"""
from __future__ import annotations
from bisect import bisect_right

class DailyAsOf:
    def __init__(self,bars):
        self.bars=sorted(bars,key=lambda b:b.end)
        self.ends=[b.end for b in self.bars]
    def pct(self,known,days=5):
        i=bisect_right(self.ends,known)-1
        if i<days:return None
        return round(100*(self.bars[i].c/self.bars[i-days].c-1),4)

def enrich(idea_rows,symbol,coin_daily,btc_daily=None,eth_daily=None):
    """Mutates only descriptive annotations. Does not change entry/SL/TP/outcomes."""
    from mtf_engine import ms
    c=DailyAsOf(coin_daily);btc=DailyAsOf(btc_daily or []);eth=DailyAsOf(eth_daily or [])
    for row in idea_rows:
        t=ms(row['at'])
        cr=c.pct(t);br=btc.pct(t);er=eth.pct(t)
        ctx=row.setdefault('global_context_at_signal',{})
        ctx.update({'coin_5d_ret_pct':cr,'btc_5d_ret_pct':br,'eth_5d_ret_pct':er,
                    'coin_vs_btc_5d_pctpts':round(cr-br,4) if cr is not None and br is not None else None,
                    'eth_vs_btc_5d_pctpts':round(er-br,4) if er is not None and br is not None else None,
                    'macro':'UNKNOWN_NOT_HISTORICALLY_RECONSTRUCTED',
                    'sector':'UNKNOWN_NOT_HISTORICALLY_RECONSTRUCTED',
                    'oi':'UNKNOWN_NOT_HISTORICALLY_RECONSTRUCTED',
                    'funding':'UNKNOWN_NOT_HISTORICALLY_RECONSTRUCTED',
                    'point_in_time_only':True})
    return idea_rows
