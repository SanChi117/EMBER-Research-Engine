#!/usr/bin/env python3
"""Strict data gate before unchanged v0.3 portfolio grid, not a new strategy."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from history_gate_v04 import audit_strict
from validate_history_v03 import DEFAULT_END, SYMBOLS
from run_portfolio_grid_v03 import execute

def run(data_dir='data/history',out='results_04/full_validation',end=DEFAULT_END):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    gate=audit_strict(data_dir,end,SYMBOLS)
    (out/'HISTORY_GATE.json').write_text(json.dumps(gate,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if gate['status']!='READY_FOR_RESEARCH':
        blocked={'status':'BLOCKED_HISTORY','reason':'Source provenance, continuity or 1d-vs-15m OHLCV mismatch',
                 'gate':'PROVENANCE_QA_0.4', 'errors':gate['errors'],
                 'portfolio_replay_performed':False,'no_fabricated_returns':True}
        (out/'SUMMARY.json').write_text(json.dumps(blocked,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        return blocked
    result=execute(data_dir,str(out/'fixed_03_grid'),end)
    summary={'status':result['status'],'provenance_gate':'PROVENANCE_QA_0.4',
             'core_engine':'FROZEN_0.3','independent_v03_and_portfolio_grid_summary':'fixed_03_grid/SUMMARY.json',
             'full_replay':result}
    (out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return summary

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',default='data/history')
    p.add_argument('--out',default='results_04/full_validation')
    p.add_argument('--end',default=DEFAULT_END)
    a=p.parse_args();r=run(a.data_dir,a.out,a.end);print(r['status']);return 2 if r['status']=='BLOCKED_HISTORY' else 0
if __name__=='__main__':sys.exit(main())
