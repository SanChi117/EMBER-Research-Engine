#!/usr/bin/env python3
"""Reproducibility / lifecycle audit inspired by Kimi's engineering checklist.

Independent READ-ONLY companion to MTF 0.3: DOES NOT produce/alter trading signals,
entry routes, SL, TP, position size, or performance statistics.
Public research fixture only. No network and no trading functions.
"""
from __future__ import annotations
import argparse, hashlib, json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from dataclasses import fields
from mtf_engine import load_csv, route_replay, Q, ms, iso

FREEZE_KEYS=('id','route','parent_id','trigger_id','vc_id','side','known','entry','stop','target',
             'net_rr','qty','unit_risk','note','target_tf','capital_risk_pct')
EXECUTED_STATUSES=frozenset(('SL','SL_FIRST_AMBIGUOUS','TP','TIME_EXIT'))
NON_EXECUTED_STATUSES=frozenset(('NO_FILL','TARGET_BEFORE_FILL','AMBIGUOUS_BEFORE_FILL',
                                 'INVALIDATED_BEFORE_FILL','GAP_BEYOND_STOP_BEFORE_FILL',
                                 'PENDING_UNRESOLVED'))


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def invariant_prefix(full_ideas, prefix_ideas, cutoff):
    """Only as-known ORIGINAL idea fields are frozen; not the future fill outcome."""
    old={row['id']:row for row in prefix_ideas if row['known']<=cutoff}
    new={row['id']:row for row in full_ideas if row['known']<=cutoff}
    issues=[]
    if len(old)!=len([r for r in prefix_ideas if r['known']<=cutoff]):
        issues.append('DUPLICATE_PREFIX_ID')
    if len(new)!=len([r for r in full_ideas if r['known']<=cutoff]):
        issues.append('DUPLICATE_FULL_ID')
    if old.keys()!=new.keys():
        issues.append('PREFIX_ID_MISMATCH:' + str({'absent_in_future': sorted(old.keys()-new.keys()),
                                                   'retroactively_created': sorted(new.keys()-old.keys())}))
    for key in old.keys()&new.keys():
        for field in FREEZE_KEYS:
            if old[key].get(field)!=new[key].get(field):
                issues.append('RETROACTIVE_REWRITE:'+key+':'+field)
        # Once an observed execution is fully known at the cutoff, the outcome
        # must not change merely because later bars were appended.
        if old[key].get('exit') and ms(old[key]['exit'])<=cutoff:
            for field in ('fill','exit','status','r','ambiguous'):
                if old[key].get(field)!=new[key].get(field):
                    issues.append('RETROACTIVE_RESOLUTION:'+key+':'+field)
    return {'cutoff_utc':iso(cutoff),'prefix_ideas':len(old),'full_ideas_at_cutoff':len(new),
            'passed':not issues,'issues':issues}


def audit_execution(ideas):
    """Prove IDEA isn't counted as a filled trade without a candle-level fill.

    NOTE: A candle touch is NOT an exchange fill/ack. This is PAPER only.
    """
    issues=[];events=[];statuses=Counter();route_status=Counter()
    for row in ideas:
        iid=row['id'];known=row['known'];status=row['status'];statuses[status]+=1
        route_status[(row['route'],status)]+=1
        events.append({'at':iso(known),'kind':'IDEA_PUBLISHED','id':iid,'route':row['route'],
                       'execution':'NOT_AN_ORDER'})
        if status not in EXECUTED_STATUSES|NON_EXECUTED_STATUSES|{'CENSORED'}:
            issues.append('UNKNOWN_STATUS:'+iid+':'+status)
        fill=row.get('fill');exit_at=row.get('exit');realized=row.get('r')
        if fill:
            fm=ms(fill)
            if fm<known:issues.append('FILL_BEFORE_IDEA:'+iid)
            events.append({'at':fill,'kind':'MODEL_LIMIT_TOUCH_NOT_EXCHANGE_ACK','id':iid,
                           'route':row['route'],'execution':'ASSUMED_NOT_CONFIRMED'})
        if exit_at:
            xm=ms(exit_at)
            if not fill:issues.append('EXIT_WITHOUT_FILL:'+iid)
            elif xm<ms(fill):issues.append('EXIT_BEFORE_FILL:'+iid)
            if xm<known:issues.append('EXIT_BEFORE_IDEA:'+iid)
            events.append({'at':exit_at,'kind':'MODEL_EXIT','id':iid,'route':row['route'],
                           'status':status,'model_r':realized})
        if realized is not None:
            if status not in EXECUTED_STATUSES:issues.append('R_ON_NONEXECUTED:'+iid)
            if not fill or not exit_at:issues.append('R_WITHOUT_COMPLETE_PATH:'+iid)
        if status in EXECUTED_STATUSES and realized is None:
            issues.append('EXECUTED_MISSING_R:'+iid)
        if status in NON_EXECUTED_STATUSES and (fill or exit_at or realized is not None):
            issues.append('NONEXECUTED_HAS_FILL_EXIT_OR_R:'+iid)
        if status=='CENSORED' and (not fill or exit_at or realized is not None):
            issues.append('CENSORED_MUST_HAVE_FILL_BUT_NO_EXIT_R:'+iid)
    events.sort(key=lambda x:(ms(x['at']),{'IDEA_PUBLISHED':0,'MODEL_LIMIT_TOUCH_NOT_EXCHANGE_ACK':1,'MODEL_EXIT':2}[x['kind']],x['id']))
    return {'passed':not issues,'issues':issues,'idea_count':len(ideas),
            'model_filled':sum(bool(x.get('fill')) for x in ideas),
            'model_completed':sum(x.get('r') is not None for x in ideas),
            'not_filled':sum(x['status'] in NON_EXECUTED_STATUSES for x in ideas),
            'censored':sum(x['status']=='CENSORED' for x in ideas),
            'statuses':dict(statuses),
            'route_status':{f'{k[0]}/{k[1]}':v for k,v in route_status.items()},
            'execution_disclaimer':'Kline touch is NOT an exchange fill. Event ledger is retrospective, not live or portfolio PnL.'}, events


def audit_fixture(data_path,daily_path,output,cutoffs=(500,700,860,930),
                  fee=.0005,slippage=.0002):
    bars,barsha=load_csv(data_path,'BTCUSDT','15m')
    days,daysha=load_csv(daily_path,'BTCUSDT','1d')
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    combined=[];ledger=[];invariants=[];cross_cost=[]
    for policy in ('COURSE_PARENT_FTA','V22_FIRST_OBSTACLE'):
        full=route_replay(bars,'BTCUSDT',native={'1d':days},fta_policy=policy,fee=fee,slippage=slippage)
        current=full['qualified_ideas']
        data,ev=audit_execution(current)
        data['fta_policy']=policy
        combined.append(data)
        for x in ev:ledger.append({'fta_policy':policy,**x})
        for cut in cutoffs:
            if not 10<cut<len(bars):continue
            previous=route_replay(bars[:cut],'BTCUSDT',native={'1d':days},fta_policy=policy,fee=fee,slippage=slippage)
            row=invariant_prefix(current,previous['qualified_ideas'],bars[cut-1].end)
            row['fta_policy']=policy;invariants.append(row)
        stress=route_replay(bars,'BTCUSDT',native={'1d':days},fta_policy=policy,fee=fee*2,slippage=slippage*2)
        orig_ids={x['id'] for x in current};stress_ids={x['id'] for x in stress['qualified_ideas']}
        # Cost filters can remove prospective ideas: do not force same set.
        cross_cost.append({'fta_policy':policy,'base_idea_count':len(orig_ids),'cost_x2_idea_count':len(stress_ids),
                           'base_r_by_route':{k:v['total_R_independent'] for k,v in full['routes'].items()},
                           'cost_x2_r_by_route':{k:v['total_R_independent'] for k,v in stress['routes'].items()},
                           'not_a_portfolio':True})
    source_root=Path(__file__).resolve().parent
    result={
      'audit_id':'KIMI_ENGINEERING_SELECTION_20261014',
      'status':'PASS' if all(x['passed'] for x in combined+invariants) else 'FAIL',
      'inputs':{'15m':{'sha256':barsha,'count':len(bars),'first':iso(bars[0].start),'last':iso(bars[-1].end)},
                '1d':{'sha256':daysha,'count':len(days)}},
      'software_sha256':{'mtf_engine_py':sha256(source_root/'mtf_engine.py'),
                         'audit_py':sha256(__file__)},
      'check_policy':{'prefix_cutoffs':list(cutoffs),'same_idea_original_fields_frozen':list(FREEZE_KEYS),
                      'outcome_after_cutoff_may_change':True,'model_fill_not_exchange_ack':True},
      'prefix_invariants':invariants,'execution_invariants':combined,
      'cost_stress_summary':cross_cost,
      'limitations':['Only BTC 1000x15m and native 1d; not a true long 5-coin backtest',
                     'No manual visually confirmed lesson labels',
                     'Historical kline-touch outcomes are not exchange fills',
                     'No independent portfolio MaxDD or untouched OOS']}
    (output/'REPORT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (output/'EVENT_LEDGER.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in sorted(ledger,key=lambda x:(ms(x['at']),x['fta_policy'],x['id']))),encoding='utf-8')
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',default='data/BTCUSDT_15m_KIMI_1000.csv')
    p.add_argument('--daily',default='data/BTCUSDT_1d_KIMI_60.csv')
    p.add_argument('--out',default='audit_kimi_selected')
    args=p.parse_args()
    r=audit_fixture(args.data,args.daily,args.out)
    print(json.dumps({'status':r['status'],'prefix_checks':len(r['prefix_invariants']),
                      'execution_checks':len(r['execution_invariants']),
                      'model_filled':sum(x['model_filled'] for x in r['execution_invariants']),
                      'model_completed':sum(x['model_completed'] for x in r['execution_invariants'])},ensure_ascii=False))
    raise SystemExit(0 if r['status']=='PASS' else 1)

if __name__=='__main__':main()
