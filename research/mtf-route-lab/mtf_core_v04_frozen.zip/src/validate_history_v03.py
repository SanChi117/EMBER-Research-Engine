#!/usr/bin/env python3
"""Read-only, strict Binance USDT-M CSV completeness/provenance verifier.

Do not claim exchange authentication from an arbitrary CSV alone; an optional
Vision manifest records verified archive URLs/hashes (use official downloader).
"""
from __future__ import annotations
import argparse,hashlib,json,sys
from pathlib import Path
from mtf_engine import load_csv,ms,STEPS,iso

SYMBOLS=('BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','BCHUSDT')
TF_START={'15m':ms('2026-04-01T00:00:00Z'),'1d':ms('2024-01-01T00:00:00Z')}
DEFAULT_END='2026-10-13T00:00:00Z'

def audit(data_dir,end=DEFAULT_END,symbols=SYMBOLS):
    root=Path(data_dir);endms=ms(end);result={'status':'BLOCKED','expected_end_utc':iso(endms),'source':'Binance USD-M expected; not self-authenticating', 'symbols':{},'errors':[]}
    if endms%(86400*1000):raise ValueError('End must be UTC midnight')
    manifest=root/'manifest_vision.json'
    verified={};origin_type=None
    if manifest.exists():
        content=json.loads(manifest.read_text(encoding='utf-8'))
        for x in content:verified[(x['symbol'],x['tf'])]=x
        origin_type='VISION_SHA256'
    else:
        # REST downloader emits its own manifest.json of file hashes. A local
        # digest only establishes byte consistency, not Binance authenticity.
        rest=root/'manifest.json'
        if rest.exists():
            content=json.loads(rest.read_text(encoding='utf-8'))
            if content.get('origin')!='https://fapi.binance.com/fapi/v1/klines':
                raise ValueError('Unrecognized REST manifest origin')
            for x in content['data']:verified[(x['symbol'],x['tf'])]=x
            origin_type='REST_MANIFEST_LOCAL_SHA256'
    result['source_manifest_type']=origin_type or 'NONE_NO_PROVENANCE'
    for symbol in symbols:
        rows={};result['symbols'][symbol]={}
        for tf,start in TF_START.items():
            path=root/f'{symbol}_{tf}.csv'
            entry={'file':str(path.relative_to(root)),'status':'MISSING'}
            result['symbols'][symbol][tf]=entry
            if not path.exists():
                result['errors'].append(f'MISSING_FILE {symbol} {tf}')
                continue
            try:
                bars,sha=load_csv(path,symbol,tf)
                if not bars:raise ValueError('Empty dataset')
                if bars[0].start!=start:raise ValueError(f'first {iso(bars[0].start)} != required {iso(start)}')
                if bars[-1].end!=endms:raise ValueError(f'last {iso(bars[-1].end)} != required {iso(endms)}')
                if len(bars)!=(endms-start)//STEPS[tf]:raise ValueError('wrong candle count')
                if any(b.start%STEPS[tf] for b in bars):raise ValueError('non-UTC boundary')
                info=verified.get((symbol,tf))
                if info and info.get('sha256')!=sha:raise ValueError('Vision manifest hash mismatch')
                entry.update({'status':'COMPLETE','candles':len(bars),'first':iso(bars[0].start),
                              'last':iso(bars[-1].end),'sha256':sha,
                              'source_checksum_manifest':bool(info),
                              'archive_sources':len(info.get('sources',[])) if info else 0})
                rows[tf]=bars
            except Exception as exc:
                entry.update({'status':'INVALID','reason':str(exc)})
                result['errors'].append(f'INVALID {symbol} {tf}: {exc}')
        if len(rows)==2:
            # Compare native exchange 1D candles with the same dates aggregated
            # from Binance Futures 15m. Closed days only. Tight float tolerance
            # because Binance data CSV may round a little.
            dmap={b.start:b for b in rows['1d']}
            m=rows['15m']
            for i in range(0,len(m),96):
                chunk=m[i:i+96]
                if len(chunk)!=96:result['errors'].append(f'PARTIAL_UTC_DAY {symbol}');break
                d=dmap.get(chunk[0].start)
                if d is None:result['errors'].append(f'NO_DAILY_OVERLAP {symbol} {iso(chunk[0].start)}');break
                q=(chunk[0].o,max(b.h for b in chunk),min(b.l for b in chunk),chunk[-1].c)
                orig=(d.o,d.h,d.l,d.c)
                if any(abs(x-y)>max(1e-7,abs(y)*1e-7) for x,y in zip(q,orig)):
                    result['errors'].append(f'MISMATCH_DAILY_AND_15M {symbol} {iso(d.start)}')
                    break
    if not result['errors']:
        result['status']='READY_FOR_RESEARCH'
        result['note']='Complete bars and internal OHLC cross-validation; exchange authenticity relies on provenance outside CSV.'
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',default='data/history')
    p.add_argument('--end',default=DEFAULT_END)
    p.add_argument('--out',default='results_03/history_audit.json')
    p.add_argument('--symbols',default=','.join(SYMBOLS))
    a=p.parse_args();r=audit(a.data_dir,a.end,tuple(a.symbols.split(',')))
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(r['status'],'errors',len(r['errors']),'details in',out)
    if r['errors']:sys.exit(2)
if __name__=='__main__':main()
