#!/usr/bin/env python3
"""Audit MTF feature detections against separately hand-annotated course screenshots.

A source must actually have been viewed and timestamped to count as a verified label.
Unannotated history cannot support claims about precision/recall (unknown false positives).
"""
import argparse,json,math,sys
from collections import Counter
from pathlib import Path
from mtf_engine import aggregate,features,load_csv,ms

ALLOWED={'PIV_H','PIV_L','IMB','SNR','OB','RB','RAID'}


def compare(expected,features_by_tf):
    rows=[]
    for sample in expected:
        if sample.get('status')!='VISUALLY_VERIFIED':
            rows.append({'id':sample.get('id'),'verdict':'UNVERIFIED_SOURCE','matched_feature_id':None})
            continue
        tf=sample['tf'];kind=sample['type'];side=sample['side'];ts=ms(sample['confirmed_at'])
        lo=float(sample['lo']);hi=float(sample['hi']);tol=float(sample.get('tolerance_pct',0.002))
        if kind not in ALLOWED or side not in ('LONG','SHORT') or tf not in features_by_tf or not 0<=tol<=.05 or not(0<lo<=hi):
            raise ValueError('Invalid label: '+str(sample.get('id')))
        matches=[]
        for f in features_by_tf[tf]:
            if f.type!=kind or f.side!=side or f.known!=ts:continue
            if abs(f.lo-lo)<=tol*lo and abs(f.hi-hi)<=tol*hi:
                matches.append(f)
        rows.append({'id':sample.get('id'),'verdict':'MATCH' if matches else 'MISS','matched_feature_id':matches[0].id if matches else None,'source_url':sample.get('source_url')})
    counts=Counter(r['verdict'] for r in rows)
    tested=counts['MATCH']+counts['MISS']
    return {'annotated_verified_total':tested,'matches':counts['MATCH'],'misses':counts['MISS'],'unverified_excluded':counts['UNVERIFIED_SOURCE'],'verified_label_recall':round(counts['MATCH']/tested,4) if tested else None,'precision':'UNKNOWN_NOT_FULLY_LABELED','rows':rows}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--15m',dest='data',required=True);p.add_argument('--1d',default=None)
    p.add_argument('--labels',required=True);p.add_argument('--out',default='results_label_audit.json')
    args=p.parse_args();bars,_=load_csv(args.data)
    streams={tf:aggregate(bars,tf) for tf in ('15m','1h','4h','1d','1w')}
    if args.__dict__['1d']:
        d,_=load_csv(args.__dict__['1d'],tf='1d');streams['1d']=[x for x in d if x.end<=bars[-1].end]
        streams['1w']=aggregate(streams['1d'],'1w')
    labels=json.loads(Path(args.labels).read_text(encoding='utf-8'))
    if not isinstance(labels,list):raise ValueError('Labels JSON must be list')
    result=compare(labels,{tf:features(a,tf) for tf,a in streams.items()})
    Path(args.out).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False))
    if result['misses']:sys.exit(2)
if __name__=='__main__':main()
