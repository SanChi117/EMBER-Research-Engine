#!/usr/bin/env python3
"""Post-processor for the *unchanged* MTF 0.3 2-FTA x 2-cost grid.

No outside market data are substituted. Refuses anything but full validated
USD-M Futures history and preserves all scenarios rather than picking winners.
"""
from __future__ import annotations
import argparse,hashlib,json,sys
from collections import defaultdict
from pathlib import Path
from mtf_engine import load_csv,iso,ms
from paper_portfolio_v03 import portfolio
from run_research_v03 import run,FTA,COSTS,SYMBOLS,DEFAULT_END,PHASES
from check_frozen_engine_v03 import check as check_engine


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def cohort(trades):
    pnl=[x['pnl_quote'] for x in trades]
    loss=-sum(x for x in pnl if x<0);gain=sum(x for x in pnl if x>0)
    return {'model_completed':len(trades),'net_quote_pnl':round(sum(pnl),8),
            'wins':sum(x>0 for x in pnl),'losses':sum(x<0 for x in pnl),
            'PF_model':round(gain/loss,6) if loss else None,
            'avg_R':round(sum(t['r_on_planned_risk'] for t in trades)/len(trades),6) if trades else None,
            'limit_not_exchange_fills':True}

def execute(data_dir='data/history',out='results_03/full_validation',end=DEFAULT_END):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    core_check=check_engine(Path(__file__).parent/'mtf_engine.py')
    (out/'CORE_LOCK.json').write_text(json.dumps(core_check,indent=2)+'\n',encoding='utf-8')
    if core_check['status']!='PASS_CORE_UNCHANGED':
        raise RuntimeError('Frozen 0.3 trading core checksum changed')
    res=run(data_dir,str(out/'independent_grid'),end,SYMBOLS)
    if res['status']=='BLOCKED_HISTORY':
        summary={'status':'BLOCKED_HISTORY','reason':'10 mandatory 5-coin futures CSV missing/invalid',
                 'history_errors':res.get('errors'),'portfolio_replay_performed':False,
                 'visual_educational_labels_verified':0,'no_untouched_oos':True}
        (out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        return summary
    bars={s:load_csv(Path(data_dir)/(s+'_15m.csv'),s,'15m')[0] for s in SYMBOLS}
    all_results={}
    for policy in FTA:
        for scenario,fee,slip in COSTS:
            key=policy+'__'+scenario
            path=out/'independent_grid'/key
            ideas=[];sha={}
            for symbol in SYMBOLS:
                f=path/(symbol+'_ideas.jsonl')
                sha[symbol]=digest(f)
                ideas.extend({**json.loads(line),'symbol':symbol} for line in f.read_text(encoding='utf-8').splitlines() if line.strip())
            p=portfolio(bars,ideas,policy=policy,fee=fee,slippage=slip)
            root=out/'portfolio_model'/key;root.mkdir(parents=True,exist_ok=True)
            for name,obj in [('SUMMARY.json',p['summary']),('EQUITY_CLOSED.json',p['closed_equity_curve'])]:
                (root/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            for name,collection in [('TRADES.jsonl',p['trades']),('LEDGER.jsonl',p['ledger'])]:
                (root/name).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in collection),encoding='utf-8')
            phases={}
            for name,left,right in PHASES:
                phases[name]=cohort([x for x in p['trades'] if ms(left)<=ms(x['signal_at'])<ms(right)])
            all_results[key]={'model':p['summary'],'phases_by_signal_timestamp':phases,
                              'idea_file_sha256':sha,'trade_ledger_sha256':digest(root/'TRADES.jsonl')}
    summary={'status':'PORTFOLIO_OHLC_PROXY_DONE_NOT_VALIDATED',
       'algorithm':'MTF_ROUTE_RESEARCH_0.3.0_CORE_UNMODIFIED',
       'long_history_internal_audit':'PASS','macro':'UNKNOWN_NOT_A_BACKTEST_FILTER',
       'cost_assumptions':['BASE fee 0.05%, slippage 0.02% per side',
                           'COST_X2 fee 0.10%, slippage 0.04% per side'],
       'execution_limits':'Candle touch, not exchange confirmation; no funding, tick/lot, spread book, liquidations',
       'visual_educational_labels_verified':0,'untouched_oos':False,
       'conclusion':'Performance MAY NOT be called proven without teacher-verified chart labels and untouched validation',
       'scenario_results':all_results}
    (out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return summary

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',default='data/history');p.add_argument('--out',default='results_03/full_validation')
    p.add_argument('--end',default=DEFAULT_END)
    args=p.parse_args();r=execute(args.data_dir,args.out,args.end)
    print(r['status']);sys.exit(2 if r['status']=='BLOCKED_HISTORY' else 0)
if __name__=='__main__':main()
