import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from run_research_v03 import run,cohort,regime

class ResearchRunner(unittest.TestCase):
    def test_hard_stop_no_data(self):
        with tempfile.TemporaryDirectory() as d:
            result=run(data_dir=d,out=Path(d)/'output')
            self.assertEqual(result['status'],'BLOCKED_HISTORY')
            self.assertTrue((Path(d)/'output'/'SUMMARY.json').exists())
    def test_unfilled_ideas_not_counted_as_losses_or_wins(self):
        result=cohort([{'route':'B_IDM','status':'NO_FILL','r':None},
                       {'route':'B_IDM','status':'SL','r':-1,'known':10,'id':'id'}])
        self.assertEqual(result['B_IDM']['ideas'],2)
        self.assertEqual(result['B_IDM']['resolved_model'],1)
        self.assertIsNone(result['B_IDM']['portfolio_max_dd'])
    def test_regime_unknown_is_not_assumed_to_be_zero(self):
        self.assertEqual(regime({'global_context_at_signal':{'btc_5d_ret_pct':None}}),'BTC_5D_UNKNOWN')
