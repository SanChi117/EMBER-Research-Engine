import sys,unittest,urllib.parse,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from get_history import pull,save
from mtf_engine import Q,load_csv

class Downloader(unittest.TestCase):
    def test_closed_bars_and_paging(self):
        rows=[[i*Q,'100','101','99','100','2',i*Q+Q-1,'100','7','1','90','0'] for i in range(4)]
        def provider(url):
            x=urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
            k=int(x['startTime'][0]);return [r for r in rows if r[0]>=k][:2]
        out=pull('BTCUSDT','15m',0,4*Q,provider,rate_sleep=0)
        self.assertEqual(len(out),4)
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'bar.csv';save(out,path)
            a,h=load_csv(path,'BTCUSDT');self.assertEqual(len(a),4)
    def test_does_not_include_open_future(self):
        rows=[[i*Q,'100','101','99','100','2',i*Q+Q-1,'100','7','1','90','0'] for i in range(4)]
        out=pull('BTCUSDT','15m',0,3*Q,lambda _:rows,rate_sleep=0)
        self.assertEqual(len(out),3)
    def test_gap_fails_closed(self):
        rows=[[i*Q,'100','101','99','100','2',i*Q+Q-1,'100','7','1','90','0'] for i in (0,2,3)]
        with self.assertRaises(RuntimeError):pull('BTCUSDT','15m',0,4*Q,lambda _:rows,rate_sleep=0)
if __name__=='__main__':unittest.main()
