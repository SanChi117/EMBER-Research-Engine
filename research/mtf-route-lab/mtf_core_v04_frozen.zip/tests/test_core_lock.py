import sys,unittest,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from check_frozen_engine_v03 import check,EXPECTED
class CoreLockTests(unittest.TestCase):
 def test_core_unchanged(self):
  p=Path(__file__).resolve().parents[1]/'src'/'mtf_engine.py'
  r=check(p)
  self.assertEqual(r['status'],'PASS_CORE_UNCHANGED')
  self.assertEqual(r['core_sha256'],EXPECTED)
 def test_core_mutation_detected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'mtf_engine.py';p.write_text('changed',encoding='utf-8')
   self.assertEqual(check(p)['status'],'FAIL_CORE_MUTATED')
