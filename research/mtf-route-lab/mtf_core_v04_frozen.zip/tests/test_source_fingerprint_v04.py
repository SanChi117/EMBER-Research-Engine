"""Deterministic assertions grounded in public Binance spot and UM daily/15m probes."""
import json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from source_fingerprint_v04 import fixture_report,classify
from mtf_engine import Bar,load_csv
ROOT=Path(__file__).resolve().parents[1]

class SourceFingerprint(unittest.TestCase):
    def test_kimi_15m_fixture_matches_spot_not_usdm(self):
        result=fixture_report(ROOT/'data')['files']['BTCUSDT_15m_KIMI_1000.csv']
        self.assertEqual(result['status'],'MATCHES_SPOT_NOT_FUTURES')
        self.assertTrue(any(x['matches_spot'] for x in result['checks']))
        self.assertTrue(any(x['matches_futures'] is False for x in result['checks']))
    def test_kimi_daily_fixture_matches_spot_not_usdm(self):
        result=fixture_report(ROOT/'data')['files']['BTCUSDT_1d_KIMI_60.csv']
        self.assertEqual(result['status'],'MATCHES_SPOT_NOT_FUTURES')
        self.assertTrue(result['checks'][0]['matches_spot'])
        self.assertFalse(result['checks'][0]['matches_futures'])
    def test_full_daily_fixture_last_day_is_different_from_completed_spot(self):
        bars,_=load_csv(ROOT/'data'/'BTCUSDT_1d_KIMI_60.csv','BTCUSDT','1d')
        self.assertEqual(bars[-1].start,1791763200000)
        self.assertNotEqual(bars[-1].c,81850.0)
        self.assertNotEqual(bars[-1].v,13529.90112)
        self.assertEqual(bars[-1].o,83773.12)
    def test_genuine_future_probe_is_recognized_only_as_sample(self):
        p=json.loads((ROOT/'data'/'BINANCE_PUBLIC_REFERENCE_OCT11_12.json').read_text())['probes'][0]
        o,h,l,c,v=p['futures_um']
        b=Bar(p['open_time'],p['open_time']+86400000,o,h,l,c,v,'1d')
        r=classify('BTCUSDT','1d',[b])
        self.assertEqual(r['status'],'FUTURES_SAMPLE_MATCH_ONLY_NOT_FULL_PROOF')
    def test_no_probes_cannot_claim_authenticity(self):
        b=Bar(0,900000,100,101,99,100,10,'15m')
        r=classify('BTCUSDT','15m',[b])
        self.assertEqual(r['status'],'NO_REFERENCE_OVERLAP')
if __name__=='__main__':unittest.main()
