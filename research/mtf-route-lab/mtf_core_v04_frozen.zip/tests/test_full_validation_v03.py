import sys,unittest,tempfile,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from run_portfolio_grid_v03 import execute,cohort

class FullValidationTests(unittest.TestCase):
  def test_no_data_is_explicitly_blocked(self):
    with tempfile.TemporaryDirectory() as d:
      path=Path(d)
      result=execute(str(path/'missing'),str(path/'results'))
      self.assertEqual(result['status'],'BLOCKED_HISTORY')
      self.assertFalse(result['portfolio_replay_performed'])
      self.assertTrue((path/'results'/'SUMMARY.json').exists())
  def test_no_trades_has_undefined_pf(self):
    r=cohort([])
    self.assertIsNone(r['PF_model'])
    self.assertIsNone(r['avg_R'])
  def test_uses_close_pnl_not_unfilled_ideas(self):
    r=cohort([{'pnl_quote':-5,'r_on_planned_risk':-1},{'pnl_quote':10,'r_on_planned_risk':2}])
    self.assertEqual(r['net_quote_pnl'],5)
    self.assertEqual(r['PF_model'],2)
if __name__=='__main__':unittest.main()
