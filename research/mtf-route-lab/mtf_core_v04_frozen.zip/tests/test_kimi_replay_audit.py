"""Additional strict checks sourced from the Kimi protocol; no foreign signal logic."""
import unittest, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from kimi_replay_audit import invariant_prefix,audit_execution,FREEZE_KEYS


def sample(status='NO_FILL',r=None,fill=None,exit_at=None):
    a=dict(id='abc',route='A_VC_IMB_SNR',parent_id='p',trigger_id='t',vc_id='v',side='LONG',
           known=1791009900000,entry=100.,stop=97.,target=107.,net_rr=2.1,qty=.1,
           unit_risk=3.,note='STRONGHL_PROXY',target_tf='4h',capital_risk_pct=.005,status=status,r=r)
    if fill:a['fill']=fill
    if exit_at:a['exit']=exit_at
    return a

class MetamorphicChronology(unittest.TestCase):
    def test_freeze_original_idea_but_ignore_future_resolution(self):
        a=sample('CENSORED',fill='2026-10-03T08:00:00Z')
        b=sample('TP',r=2.1,fill='2026-10-03T08:00:00Z',exit_at='2026-10-03T14:00:00Z')
        self.assertTrue(invariant_prefix([b],[a],a['known'])['passed'])
    def test_edit_past_entry_detected(self):
        a=sample();b={**a,'entry':105}
        self.assertFalse(invariant_prefix([b],[a],a['known'])['passed'])
    def test_retroactive_idea_detected(self):
        self.assertFalse(invariant_prefix([sample()],[],sample()['known'])['passed'])
    def test_duplicate_ids_detected(self):
        a=sample();self.assertFalse(invariant_prefix([a,a],[a],a['known'])['passed'])
    def test_resolved_outcome_change_detected(self):
        a=sample('SL',r=-1,fill='2026-10-03T08:00:00Z',exit_at='2026-10-03T09:00:00Z')
        b={**a,'r':2.0}
        self.assertFalse(invariant_prefix([b],[a],1791020000000)['passed'])

class Lifecycle(unittest.TestCase):
    def test_unfilled_is_not_trade(self):
        d,_=audit_execution([sample()]);self.assertTrue(d['passed'])
        self.assertEqual(d['model_filled'],0);self.assertEqual(d['model_completed'],0)
    def test_reject_profit_credit_without_fill(self):
        d,_=audit_execution([sample('NO_FILL',r=5.0)]);self.assertFalse(d['passed'])
    def test_censored_filled_but_no_realized_pnl(self):
        d,_=audit_execution([sample('CENSORED',fill='2026-10-03T08:00:00Z')])
        self.assertTrue(d['passed']);self.assertEqual(d['model_filled'],1)
        self.assertEqual(d['model_completed'],0)
    def test_model_trade_requires_fill_and_exit(self):
        d,_=audit_execution([sample('SL',r=-1)]);self.assertFalse(d['passed'])
    def test_fill_cannot_predate_idea(self):
        d,_=audit_execution([sample('CENSORED',fill='2026-10-03T05:00:00Z')]);self.assertFalse(d['passed'])
    def test_model_exit_history(self):
        d,events=audit_execution([sample('SL',r=-1,fill='2026-10-03T08:00:00Z',exit_at='2026-10-03T09:00:00Z')])
        self.assertTrue(d['passed']);self.assertEqual(len(events),3)
        self.assertEqual(events[0]['kind'],'IDEA_PUBLISHED')

if __name__=='__main__':unittest.main()
