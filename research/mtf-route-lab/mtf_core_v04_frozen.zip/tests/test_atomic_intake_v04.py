import json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from obtain_history_v04 import obtain
from history_gate_v04 import audit_strict

class TransactionalHistoryTests(unittest.TestCase):
    def test_download_failures_never_overwrite_preexisting_files(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);work=root/'history';work.mkdir()
            sentinel=work/'important.txt';sentinel.write_text('original bytes must survive')
            with patch('obtain_history_v04.subprocess.run',return_value=SimpleNamespace(returncode=1,stdout='',stderr='dns')) as sub:
                result=obtain(str(work),out=str(root/'download.json'),download=True)
            self.assertEqual(result['status'],'BLOCKED_HISTORY')
            self.assertEqual(sub.call_count,2)
            self.assertTrue(sentinel.exists())
            self.assertEqual(sentinel.read_text(),'original bytes must survive')
            self.assertEqual(sorted(x.name for x in root.iterdir()),['download.json','history'])
            self.assertFalse(result['old_directory_overwritten'])
    def test_bad_json_manifest_is_blocked_without_uncaught_exception(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d)/'manifest_vision.json').write_text('NOPE {invalid')
            r=audit_strict(d)
            self.assertEqual(r['status'],'BLOCKED_HISTORY')
            self.assertIn('BASE_HISTORY_AUDIT_FAILED',' '.join(r['errors']))

if __name__=='__main__':unittest.main()
