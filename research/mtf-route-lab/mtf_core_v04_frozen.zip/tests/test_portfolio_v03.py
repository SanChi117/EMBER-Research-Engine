import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from mtf_engine import Bar
from paper_portfolio_v03 import portfolio

Q=900000

def bar(i,o,h,l,c,s=0):return Bar(s+i*Q,s+(i+1)*Q,o,h,l,c,1.,'15m')

def idea(i=0,side='LONG',symbol='BTCUSDT',name='test',policy='COURSE_PARENT_FTA',entry=99,stop=98,target=105):
    return {'id':name,'symbol':symbol,'side':side,'entry':entry,'stop':stop,'target':target,'known':(i+1)*Q,
            'route':'A_VC_IMB_SNR','note':policy+'; fixed', 'parent_id':'parent'}

class PortfolioTests(unittest.TestCase):
    def test_tp_only_after_fill(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101,98.5,99),bar(2,99,105.5,98.8,105)]
        out=portfolio({'BTCUSDT':bars},[idea()],policy='COURSE_PARENT_FTA')
        self.assertEqual(out['summary']['completed_model_trades'],1)
        self.assertEqual(out['trades'][0]['status'],'TP')
        self.assertGreater(out['summary']['net_pnl'],0)
        self.assertEqual(out['trades'][0]['fill_at'],'1970-01-01T00:15:00Z')
    def test_target_before_entry_never_fills(self):
        bars=[bar(0,100,101,99,100),bar(1,101,106,100.5,106)]
        out=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(out['summary']['completed_model_trades'],0)
        self.assertEqual(out['summary']['rejections']['TARGET_BEFORE_FILL'],1)
    def test_both_sides_same_bar_ambiguous_rejected_pre_fill(self):
        bars=[bar(0,100,101,99,100),bar(1,100,106,97,99)]
        out=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(out['summary']['completed_model_trades'],0)
        self.assertEqual(out['summary']['rejections']['TARGET_BEFORE_FILL_UNCLEAR_PATH'],1)
    def test_filled_then_both_sl_tp_is_sl(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101,98.5,99),bar(2,99,106,97.5,101)]
        out=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(out['trades'][0]['status'],'SL_FIRST_AMBIGUOUS')
        self.assertLess(out['summary']['net_pnl'],0)
    def test_stop_on_fill_bar_is_sl(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101,97.5,98.5)]
        out=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(out['trades'][0]['status'],'SL')
    def test_censored_fill_not_realized(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101,98.5,99)]
        out=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(out['summary']['completed_model_trades'],0)
        self.assertEqual(out['summary']['ending_open_positions'],1)
        self.assertEqual(out['summary']['net_pnl'],0)
    def test_limit_pending_at_end(self):
        bars=[bar(0,100,101,99,100)]
        out=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(out['summary']['ending_pending_orders'],1)
    def test_dedupe_one_symbol(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101,98.5,99),bar(2,99,105.5,98.8,105)]
        out=portfolio({'BTCUSDT':bars},[idea(name='aa'),idea(name='bb')])
        self.assertEqual(out['summary']['completed_model_trades'],1)
        self.assertEqual(out['summary']['rejections']['BUSY_SYMBOL'],1)
    def test_duplicate_id_rejected(self):
        bars=[bar(0,100,101,99,100)]
        with self.assertRaisesRegex(ValueError,'duplicate'):
            portfolio({'BTCUSDT':bars},[idea(),idea()])
    def test_wrong_policy_rejected(self):
        bars=[bar(0,100,101,99,100)]
        with self.assertRaisesRegex(ValueError,'FTA policy'):
            portfolio({'BTCUSDT':bars},[idea(policy='V22_FIRST_OBSTACLE')],policy='COURSE_PARENT_FTA')
    def test_bad_signal_time_rejected(self):
        bars=[bar(0,100,101,99,100)]
        with self.assertRaisesRegex(ValueError,'closed candle'):
            portfolio({'BTCUSDT':bars},[idea(i=1)])
    def test_gap_through_stop_cancelled(self):
        bars=[bar(0,100,101,99,100),bar(1,97,100,96.5,99)]
        out=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(out['summary']['completed_model_trades'],0)
        self.assertEqual(out['summary']['rejections']['GAP_BEYOND_STOP'],1)
    def test_short_stop_and_tp(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101.5,99,101),bar(2,101,101.8,95,96)]
        out=portfolio({'BTCUSDT':bars},[idea(side='SHORT',entry=101,stop=102,target=96)])
        self.assertEqual(out['trades'][0]['status'],'TP')
    def test_deterministic_repeat(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101,98.5,99),bar(2,99,105.5,98.8,105)]
        a=portfolio({'BTCUSDT':bars},[idea()])
        b=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(a,b)
    def test_two_symbol_gross_limit(self):
        btc=[bar(0,100,101,99,100),bar(1,100,101,98.5,99),bar(2,99,101,98.5,99)]
        eth=[bar(0,100,101,99,100),bar(1,100,101,98.5,99),bar(2,99,101,98.5,99)]
        x=portfolio({'BTCUSDT':btc,'ETHUSDT':eth},[idea(name='btc'),idea(symbol='ETHUSDT',name='eth')],max_concurrent=1)
        self.assertEqual(x['summary']['ending_open_positions'],1)
        self.assertEqual(x['summary']['rejections']['CAPACITY'],1)
    def test_short_history_requires_continuity(self):
        bars=[bar(0,100,101,99,100),bar(2,100,101,99,100)]
        with self.assertRaisesRegex(ValueError,'continuity'):
            portfolio({'BTCUSDT':bars},[])

if __name__=='__main__':unittest.main()

class PortfolioAdditionalTests(unittest.TestCase):
    def test_time_exit_one_bar(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101,98.5,99)]
        r=portfolio({'BTCUSDT':bars},[idea()],hold_bars=1)
        self.assertEqual(r['summary']['completed_model_trades'],1)
        self.assertEqual(r['trades'][0]['status'],'TIME_EXIT')
    def test_unrealized_loss_is_visible_in_mtm(self):
        bars=[bar(0,100,101,99,100),bar(1,100,101,98.5,98.7)]
        r=portfolio({'BTCUSDT':bars},[idea()])
        self.assertEqual(r['summary']['completed_model_trades'],0)
        self.assertLess(r['summary']['ending_bar_close_MTM_equity'],1000)
        self.assertGreater(r['summary']['max_bar_close_MTM_drawdown_pct'],0)
    def test_only_conservative_assumptions_no_negative_fee(self):
        bars=[bar(0,100,101,99,100)]
        with self.assertRaises(ValueError):portfolio({'BTCUSDT':bars},[],fee=-.001)
