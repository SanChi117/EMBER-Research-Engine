import json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from mtf_engine import Feature
from compare_course_labels import compare
class CourseAudit(unittest.TestCase):
    def item(self,status):
        return dict(id='test',status=status,tf='4h',type='RB',side='LONG',lo=100,hi=101,confirmed_at='1970-01-01T01:00:00Z')
    def test_unverified_never_counts_as_accuracy(self):
        s=compare([self.item('NEEDS_VISUAL_REVIEW')],{'4h':[]})
        self.assertIsNone(s['verified_label_recall']);self.assertEqual(s['unverified_excluded'],1)
    def test_verified_match_by_known_time(self):
        item=self.item('VISUALLY_VERIFIED')
        f=Feature('rb','4h','RB','LONG',100,101,0,3600000,'TEST')
        s=compare([item],{'4h':[f]});self.assertEqual(s['matches'],1);self.assertEqual(s['precision'],'UNKNOWN_NOT_FULLY_LABELED')
    def test_late_detection_does_not_match(self):
        item=self.item('VISUALLY_VERIFIED')
        f=Feature('rb','4h','RB','LONG',100,101,0,3600001,'TEST')
        s=compare([item],{'4h':[f]});self.assertEqual(s['misses'],1)
if __name__=='__main__':unittest.main()
