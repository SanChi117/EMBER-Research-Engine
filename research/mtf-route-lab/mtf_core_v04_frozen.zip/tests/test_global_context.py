import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from mtf_engine import Bar,STEPS,iso
from global_context import DailyAsOf,enrich

class Context(unittest.TestCase):
    def setUp(self):
        self.days=[Bar(i*STEPS['1d'],(i+1)*STEPS['1d'],100,120,99,100+i,1,'1d') for i in range(10)]
    def test_today_not_visible_until_daily_closes(self):
        idx=DailyAsOf(self.days)
        self.assertIsNone(idx.pct(self.days[5].start,days=5))
        self.assertEqual(idx.pct(self.days[5].end,days=5),5.0)
    def test_annotate_does_not_change_trade(self):
        row={'at':iso(self.days[5].end),'entry':100,'stop':98,'target':106,'r':1.5,'global_context_at_signal':{'1d_pivots':'DOWN'}}
        enrich([row],'BTCUSDT',self.days,self.days,[])
        self.assertEqual((row['entry'],row['stop'],row['target'],row['r']),(100,98,106,1.5))
        self.assertEqual(row['global_context_at_signal']['coin_vs_btc_5d_pctpts'],0)
        self.assertIsNone(row['global_context_at_signal']['eth_5d_ret_pct'])
    def test_no_future_backfill(self):
        row={'at':iso(self.days[3].end),'global_context_at_signal':{}}
        enrich([row],'BTCUSDT',self.days,self.days,[])
        self.assertIsNone(row['global_context_at_signal']['coin_5d_ret_pct'])
if __name__=='__main__':unittest.main()
