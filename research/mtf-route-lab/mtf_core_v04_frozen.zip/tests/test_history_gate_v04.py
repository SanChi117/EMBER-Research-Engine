"""Fail-closed provenance checks on complete synthetic OHLCV fixtures."""
import hashlib,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import validate_history_v03 as old
from history_gate_v04 import audit_strict
from mtf_engine import ms,iso
from run_portfolio_grid_v04 import run

START=ms('2026-04-01T00:00:00Z')
END=START+2*86400000
SYMBOL='BTCUSDT'

def make_data(root, broken_volume=False):
    p=Path(root)
    head='open_time,open,high,low,close,volume,symbol\n'
    quarter=p/'BTCUSDT_15m.csv';daily=p/'BTCUSDT_1d.csv'
    quarter.write_text(head+''.join(f'{START+i*900000},100,102,99,101,5,BTCUSDT\n' for i in range(192)))
    daily.write_text(head+''.join(f'{START+i*86400000},100,102,99,101,{481 if broken_volume else 480},BTCUSDT\n' for i in range(2)))
    return quarter,daily

def make_manifest(root, provenance='vision'):
    p=Path(root)
    if provenance=='vision':
        rows=[]
        for tf in ('15m','1d'):
            url=f'https://data.binance.vision/data/futures/um/monthly/klines/{SYMBOL}/{tf}/{SYMBOL}-{tf}-2026-04.zip'
            rows.append({'symbol':SYMBOL,'tf':tf,'sha256':hashlib.sha256((p/f'{SYMBOL}_{tf}.csv').read_bytes()).hexdigest(),
                         'sources':[{'url':url,'sha256':'1'*64,'rows':192 if tf=='15m' else 2}]})
        (p/'manifest_vision.json').write_text(json.dumps(rows))
    elif provenance=='rest':
        rows=[]
        for tf in ('15m','1d'):
            rows.append({'symbol':SYMBOL,'tf':tf,'file':f'{SYMBOL}_{tf}.csv',
                         'sha256':hashlib.sha256((p/f'{SYMBOL}_{tf}.csv').read_bytes()).hexdigest()})
        (p/'manifest.json').write_text(json.dumps({'origin':'https://fapi.binance.com/fapi/v1/klines','data':rows}))

class StrictGate(unittest.TestCase):
    def gate(self,path):
        with patch.dict(old.TF_START,{'15m':START,'1d':START}):
            return audit_strict(path,iso(END),('BTCUSDT',))
    def test_catches_v03_false_ready_with_no_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            make_data(d)
            with patch.dict(old.TF_START,{'15m':START,'1d':START}):
                self.assertEqual(old.audit(d,iso(END),('BTCUSDT',))['status'],'READY_FOR_RESEARCH')
            result=self.gate(d)
            self.assertEqual(result['status'],'BLOCKED_HISTORY')
            self.assertIn('UNVERIFIED_ORIGIN', ' '.join(result['errors']))
    def test_fake_vision_source_no_checksum_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            make_data(d);make_manifest(d)
            p=Path(d)/'manifest_vision.json';x=json.loads(p.read_text());x[0]['sources'][0]['sha256']='not-a-checksum';p.write_text(json.dumps(x))
            r=self.gate(d)
            self.assertEqual(r['status'],'BLOCKED_HISTORY')
            self.assertIn('INVALID_VISION_SOURCE',' '.join(r['errors']))
    def test_good_vision_manifest_passes_consistency_but_not_remote_authentication(self):
        with tempfile.TemporaryDirectory() as d:
            make_data(d);make_manifest(d)
            r=self.gate(d)
            self.assertEqual(r['status'],'READY_FOR_RESEARCH',r['errors'])
            self.assertEqual(r['cross_checked_daily_volume_days'],2)
            self.assertIn('NOT_REMOTE_ATTESTED',r['provenance_level'])
    def test_volume_mismatch_rejected_despite_matching_prices_and_sha(self):
        with tempfile.TemporaryDirectory() as d:
            make_data(d,broken_volume=True);make_manifest(d)
            r=self.gate(d)
            self.assertEqual(r['status'],'BLOCKED_HISTORY')
            self.assertIn('DAILY_VOLUME_MISMATCH',' '.join(r['errors']))
    def test_valid_rest_manifest_weak_provenance_explicit(self):
        with tempfile.TemporaryDirectory() as d:
            make_data(d);make_manifest(d,'rest')
            r=self.gate(d)
            self.assertEqual(r['status'],'READY_FOR_RESEARCH',r['errors'])
            self.assertEqual(r['provenance_level'],'REST_URL_CLAIM_LOCAL_HASH_ONLY')
    def test_rest_file_hash_corrupted(self):
        with tempfile.TemporaryDirectory() as d:
            make_data(d);make_manifest(d,'rest')
            p=Path(d)/'BTCUSDT_1d.csv';p.write_text(p.read_text().replace('101,480','101,471'))
            r=self.gate(d)
            self.assertEqual(r['status'],'BLOCKED_HISTORY')
            self.assertIn('manifest hash mismatch',' '.join(r['errors']))
    def test_no_history_never_generates_portfolio_pnl(self):
        with tempfile.TemporaryDirectory() as d:
            r=run(str(Path(d)/'missing'),str(Path(d)/'output'),iso(END))
            self.assertEqual(r['status'],'BLOCKED_HISTORY')
            self.assertFalse(r['portfolio_replay_performed'])
            self.assertTrue((Path(d)/'output'/'HISTORY_GATE.json').exists())
    def test_manifest_without_tf_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            make_data(d);make_manifest(d)
            p=Path(d)/'manifest_vision.json';m=json.loads(p.read_text());p.write_text(json.dumps(m[:1]))
            r=self.gate(d)
            self.assertEqual(r['status'],'BLOCKED_HISTORY')
            self.assertIn('MISSING_MANIFEST_RECORD',' '.join(r['errors']))

if __name__=='__main__':unittest.main()
