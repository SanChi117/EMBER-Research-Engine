"""0.3 semantic regression cases; synthetic text-derived scenarios, NOT visually verified figures."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from mtf_engine import Bar,Feature,STEPS,features,entry_quote,route_replay,load_csv,ALGO

def candle(i,o,h,l,c,tf='1h'):
    start=i*STEPS[tf]
    return Bar(start,start+STEPS[tf],o,h,l,c,100,tf)

class RejectionWickSemantics(unittest.TestCase):
    def test_new_simultaneous_imb_does_not_cause_rb(self):
        bars=[candle(0,99,101,97,100),candle(1,109,111,104,105),candle(2,105,113,103,112)]
        ff=features(bars,'1h')
        self.assertTrue(any(x.type=='IMB' for x in ff))
        self.assertFalse(any(x.type=='RB' and x.known==bars[-1].end for x in ff))
    def test_preexisting_imb_wick_can_cause_rb(self):
        bars=[candle(0,98,100,96,99),candle(1,99,103,98,102),
              candle(2,105,110,104,107), # completed LONG FVG: 100..104
              candle(3,106,107,103,105), # wick-only dips to FVG
              candle(4,105,109,104.5,108)]
        ff=features(bars,'1h')
        self.assertTrue(any(x.type=='RB' and x.side=='LONG' and x.known==bars[-1].end for x in ff))
    def test_body_overlap_does_not_count_as_imb_wick(self):
        bars=[candle(0,98,100,96,99),candle(1,99,103,98,102),
              candle(2,105,110,104,107),
              candle(3,105,107,100,101), # bearish BODY enters FVG
              candle(4,101,109,100.5,108)]
        ff=features(bars,'1h')
        self.assertFalse(any(x.type=='RB' and x.known==bars[-1].end for x in ff))

class IndependentBranches(unittest.TestCase):
    def test_4h_vc_to_1h_idm_uses_4h_target_not_daily(self):
        anchor=Feature('anchor','1d','RB','LONG',95,103,0,1000,'lesson')
        parent=Feature('vc4','4h','SNR','LONG',99,101,2000,3000,'lesson')
        idm=Feature('idm1','1h','PIV_L','LONG',100,100,4000,5000,'pivot')
        fta4=Feature('fta4','4h','PIV_H','SHORT',107,107,100,4400,'pivot')
        fta1d=Feature('ftaD','1d','PIV_H','SHORT',115,115,100,4400,'pivot')
        idea,why=entry_quote('B_IDM',anchor,parent,idm,'LONG',5000,100,98,
            {'4h':[fta4],'1d':[fta1d]},fta_source_tf='4h')
        self.assertEqual(why,'OK');self.assertEqual(idea.target_tf,'4h')
        self.assertEqual(idea.route,'B_IDM')
    def test_double_friction_cannot_improve_net_rr(self):
        p=Feature('p','4h','RB','LONG',98,101,0,1000,'lesson')
        tr=Feature('tr','1h','RAID','LONG',97,102,2000,3000,'lesson')
        vc=Feature('vc','15m','IMB','LONG',99,101,4000,5000,'lesson')
        obs=Feature('ob','4h','PIV_H','SHORT',108,108,0,4000,'pivot')
        a,x=entry_quote('A_VC_IMB_SNR',p,tr,vc,'LONG',5000,100,98,{'4h':[obs]},min_rr=0.0)
        b,y=entry_quote('A_VC_IMB_SNR',p,tr,vc,'LONG',5000,100,98,{'4h':[obs]},min_rr=0.0,fee=.001,slippage=.0004)
        self.assertEqual(x,'OK');self.assertEqual(y,'OK')
        self.assertLess(b.net_rr,a.net_rr)
    def test_v03_not_v02_and_no_real_order_module(self):
        self.assertEqual(ALGO,'MTF_ROUTE_RESEARCH_0.3.0')
        p=Path(__file__).resolve().parents[1]
        self.assertFalse((p/'src'/'place_real_order.py').exists())

if __name__=='__main__':unittest.main()

class ImbTriggerContext(unittest.TestCase):
    def test_nested_imb_trigger_only_under_4h_rb_or_snr(self):
        from mtf_engine import permits_one_hour_imb_trigger
        def p(tf,kind):return Feature('x',tf,kind,'LONG',99,101,0,100,'lesson')
        self.assertTrue(permits_one_hour_imb_trigger(p('4h','RB')))
        self.assertTrue(permits_one_hour_imb_trigger(p('4h','SNR')))
        self.assertFalse(permits_one_hour_imb_trigger(p('4h','IMB')))
        self.assertFalse(permits_one_hour_imb_trigger(p('1h','SNR')))
