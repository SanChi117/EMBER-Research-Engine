"""Validates the strict history completeness gate without internet."""
import csv,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from validate_history_v03 import audit,TF_START,DEFAULT_END
from mtf_engine import ms

class StrictHistory(unittest.TestCase):
    def test_missing_multicoin_history_must_block(self):
        with tempfile.TemporaryDirectory() as d:
            x=audit(d,symbols=('BTCUSDT','ETHUSDT'))
            self.assertEqual(x['status'],'BLOCKED')
            self.assertEqual(len(x['errors']),4)
    def test_invalid_bar_file_must_block(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'BTCUSDT_15m.csv'
            p.write_text('open_time,open,high,low,close,volume\n0,100,101,99,100,10\n')
            x=audit(d,symbols=('BTCUSDT',))
            self.assertEqual(x['symbols']['BTCUSDT']['15m']['status'],'INVALID')
    def test_end_must_be_daily_utc(self):
        with self.assertRaises(ValueError):audit('/dev/null',end='2026-10-13T15:00:00Z',symbols=())

class FullSyntheticRange(unittest.TestCase):
    def test_cross_tf_ohlc_and_sha_manifest(self):
        import validate_history_v03 as vh,hashlib,json
        from unittest.mock import patch
        start=ms('2026-04-01T00:00:00Z'); end=start+2*86400000
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            a=p/'BTCUSDT_15m.csv';q=p/'BTCUSDT_1d.csv'
            head='open_time,open,high,low,close,volume,symbol\n'
            a.write_text(head+''.join(f'{start+i*900000},100,102,99,101,5,BTCUSDT\n' for i in range(192)))
            q.write_text(head+''.join(f'{start+i*86400000},100,102,99,101,480,BTCUSDT\n' for i in range(2)))
            manifest=[{'symbol':'BTCUSDT','tf':tf,'sha256':hashlib.sha256((p/f'BTCUSDT_{tf}.csv').read_bytes()).hexdigest(),'sources':[{'sha256':'TEST-ONLY'}]} for tf in ('15m','1d')]
            (p/'manifest_vision.json').write_text(json.dumps(manifest))
            with patch.dict(vh.TF_START,{'15m':start,'1d':start}):
                result=vh.audit(d, vh.iso(end),symbols=('BTCUSDT',))
            self.assertEqual(result['status'],'READY_FOR_RESEARCH',result['errors'])
            self.assertEqual(result['source_manifest_type'],'VISION_SHA256')
            a.write_text(a.read_text().replace('100,102,99,101','100,103,99,101',1))
            with patch.dict(vh.TF_START,{'15m':start,'1d':start}):
                bad=vh.audit(d,vh.iso(end),symbols=('BTCUSDT',))
            self.assertEqual(bad['status'],'BLOCKED')
            self.assertIn('Vision manifest hash mismatch', ' '.join(bad['errors']))
