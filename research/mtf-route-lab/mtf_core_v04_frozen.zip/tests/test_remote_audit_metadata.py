import json,unittest
from pathlib import Path

class RemoteAuditMetadataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r=json.loads((Path(__file__).resolve().parents[1]/'results_04'/'BINANCE_FUTURES_CONNECTOR_REMOTE_AUDIT.json').read_text())
    def test_calendar_and_counts(self):
        r=self.r
        self.assertEqual(sum(r['monthly_day_counts'].values()),195)
        self.assertEqual(r['checked_total_m15_candles'],195*96*5)
        self.assertEqual(r['checked_total_daily_candles'],1016*5)
        self.assertTrue(all(x['m15_candles']==18720 for x in r['per_symbol'].values()))
    def test_never_treat_remote_check_as_backtest(self):
        self.assertFalse(self.r['local_dataset_persisted'])
        self.assertFalse(self.r['full_mtf_replay_performed'])
        self.assertTrue(self.r['mtf_engine_frozen'])
