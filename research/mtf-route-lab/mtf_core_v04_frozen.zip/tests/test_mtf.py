import sys, tempfile, csv, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from mtf_engine import Bar,Feature,TradeIdea,aggregate,features,entry_quote,simulate,load_csv,route_replay,STEPS,Q

D=Q

def b(i,o=100,h=101,l=99,c=100,tf='15m',base=0):
    st=base+i*STEPS[tf];return Bar(st,st+STEPS[tf],o,h,l,c,2,tf)

def sample_idea(side='LONG',E=100,S=98,T=105,net=2.5):
    return TradeIdea('id','A_VC_IMB_SNR','pa','tr','vc',side,0,E,S,T,net,.001,2.14,'target','4h')

class Data(unittest.TestCase):
    def test_one_hour_full(self):
        assert aggregate([b(i) for i in range(3)],'1h')==[]
        out=aggregate([b(i) for i in range(4)],'1h')
        self.assertEqual(len(out),1);self.assertEqual(out[0].end,4*Q)
    def test_no_partial_four_hour(self):
        self.assertEqual(len(aggregate([b(i) for i in range(15)],'4h')),0)
        self.assertEqual(len(aggregate([b(i) for i in range(16)],'4h')),1)
    def test_native_daily_to_week(self):
        # UNIX Jan 5 1970 is Monday, 4 days after UNIX epoch.
        mon=4*86_400_000
        bars=[Bar(mon+i*86_400_000,mon+(i+1)*86_400_000,1,2,0.5,1.5,5,'1d') for i in range(7)]
        weeks=aggregate(bars,'1w');self.assertEqual(len(weeks),1);self.assertEqual(weeks[0].start,mon)
    def test_fvg_known_at_third_close(self):
        a=[b(0,o=100,h=101,l=98,c=100),b(1,o=100,h=105,l=99,c=104),b(2,o=104,h=108,l=103,c=107)]
        fv=[x for x in features(a,'15m') if x.type=='IMB']
        self.assertEqual(len(fv),1);self.assertEqual(fv[0].known,3*Q);self.assertEqual((fv[0].lo,fv[0].hi),(101,103))
    def test_pivot_only_after_two_right(self):
        a=[b(i,h=h,l=90,c=95) for i,h in enumerate([99,101,110,104,103])]
        self.assertFalse(any(x.type=='PIV_H' for x in features(a[:4],'15m')))
        piv=[x for x in features(a,'15m') if x.type=='PIV_H']
        self.assertEqual(len(piv),1);self.assertEqual(piv[0].origin,2*Q);self.assertEqual(piv[0].known,5*Q)
    def test_prefix_invariance(self):
        a=[b(i,o=100+(i%3),h=104+i%6,l=98-i%5,c=99+(i%7)) for i in range(40)]
        older=features(a[:21],'15m');late=[x for x in features(a,'15m') if x.known<=a[20].end]
        self.assertEqual(older,late)
    def test_invalid_candle_refused(self):
        with tempfile.TemporaryDirectory() as root:
            file=Path(root)/'x.csv'
            file.write_text('open_time,open,high,low,close,volume\n0,100,99,90,101,1\n')
            with self.assertRaises(ValueError):load_csv(file)
    def test_gap_refused(self):
        with tempfile.TemporaryDirectory() as root:
            file=Path(root)/'x.csv'
            file.write_text('open_time,open,high,low,close,volume\n0,100,101,90,100,1\n1800000,100,101,90,100,1\n')
            with self.assertRaises(ValueError):load_csv(file)

class Quote(unittest.TestCase):
    def setUp(self):
        self.parent=Feature('p','4h','SNR','LONG',98,99,0,100,'test')
        self.trigger=Feature('t','1h','RAID','LONG',97,101,120,200,'test')
        self.vc=Feature('f','15m','IMB','LONG',99,101,220,300,'test')
        self.pivot=Feature('up','4h','PIV_H','SHORT',106,106,0,250,'test')
    def test_time_backflow_blocked(self):
        x,y=entry_quote('A_VC_IMB_SNR',self.parent,self.trigger,self.vc,'LONG',250,100,98,{'4h':[self.pivot]})
        self.assertIsNone(x);self.assertEqual(y,'FUTURE_OR_OUT_OF_ORDER')
    def test_sl_invalid(self):
        x,y=entry_quote('A',self.parent,self.trigger,self.vc,'LONG',400,100,101,{'4h':[self.pivot]})
        self.assertIsNone(x);self.assertEqual(y,'BAD_STOP')
    def test_first_fta_not_arbitrary_rr(self):
        short=Feature('short','1h','PIV_H','SHORT',101,101,1,300,'test')
        obj,reason=entry_quote('A',self.parent,self.trigger,self.vc,'LONG',400,100,98,{'4h':[self.pivot],'1h':[short]},fta_policy='V22_FIRST_OBSTACLE')
        self.assertEqual(reason,'LOW_NET_RR');self.assertIsNone(obj)
    def test_parent_fca_vs_nearest_diff(self):
        short=Feature('short','1h','PIV_H','SHORT',101,101,1,300,'test')
        obj,reason=entry_quote('A',self.parent,self.trigger,self.vc,'LONG',400,100,98,{'4h':[self.pivot],'1h':[short]},fta_policy='COURSE_PARENT_FTA')
        self.assertEqual(reason,'OK');self.assertEqual(obj.target_tf,'4h');self.assertIn('nearer_other_tf=True',obj.note)
    def test_natural_sl_survives_costs(self):
        obj,reason=entry_quote('A',self.parent,self.trigger,self.vc,'LONG',400,100,98,{'4h':[self.pivot]})
        self.assertEqual(reason,'OK');self.assertLess(obj.net_rr,3);self.assertLessEqual(obj.qty*obj.unit_risk,.005)
        self.assertEqual(obj.stop,98)
    def test_unknown_fta_reject(self):
        o,reason=entry_quote('A',self.parent,self.trigger,self.vc,'LONG',400,100,98,{})
        self.assertIsNone(o);self.assertEqual(reason,'NO_FTA')

class Fill(unittest.TestCase):
    def test_no_fill_never_a_win(self):
        idea=sample_idea();bars=[b(0,h=101,l=100.2),b(1,h=102,l=100.3),b(2,h=103,l=100.3)]
        self.assertEqual(simulate(idea,bars,0,expiry_bars=2)['status'],'NO_FILL')
    def test_target_before_fill_is_not_tp(self):
        idea=sample_idea();bars=[b(0),b(1,o=103,h=106,l=102,c=105)]
        self.assertEqual(simulate(idea,bars,0)['status'],'TARGET_BEFORE_FILL')
    def test_target_and_entry_same_bar_is_unknown(self):
        idea=sample_idea();bars=[b(0),b(1,h=106,l=99,c=101)]
        self.assertEqual(simulate(idea,bars,0)['status'],'AMBIGUOUS_BEFORE_FILL')
    def test_stop_before_fill_is_invalidated(self):
        idea=sample_idea();bars=[b(0),b(1,o=97,h=99,l=97,c=98)]
        self.assertEqual(simulate(idea,bars,0)['status'],'GAP_BEYOND_STOP_BEFORE_FILL')
    def test_sl_first_same_bar(self):
        idea=sample_idea();bars=[b(0),b(1,h=100.1,l=99,c=100),b(2,h=106,l=97,c=103)]
        out=simulate(idea,bars,0)
        self.assertEqual(out['status'],'SL_FIRST_AMBIGUOUS');self.assertLess(out['r'],0)
    def test_sl_gap_worse_than_r(self):
        idea=sample_idea();bars=[b(0),b(1,h=100,l=99,c=100),b(2,o=97,h=98,l=96,c=97)]
        out=simulate(idea,bars,0);self.assertEqual(out['status'],'SL');self.assertLess(out['r'],-1)
    def test_tp_when_after_fill_in_different_bar(self):
        idea=sample_idea();bars=[b(0),b(1,h=101,l=99.5,c=100),b(2,o=102,h=106,l=101,c=104)]
        out=simulate(idea,bars,0);self.assertEqual(out['status'],'TP');self.assertEqual(out['r'],2.5)
    def test_censored_not_a_tp(self):
        idea=sample_idea();bars=[b(0),b(1,h=101,l=99,c=100)]
        self.assertEqual(simulate(idea,bars,0)['status'],'CENSORED')

class Engine(unittest.TestCase):
    def test_result_not_mistaken_as_portfolio(self):
        a=[b(i,o=100,h=101,l=99,c=100) for i in range(70)]
        x=route_replay(a)
        self.assertTrue(x['routes']['A_VC_IMB_SNR']['not_a_portfolio'])
        self.assertFalse(x['readiness']['history_1d_ge_50'])
        self.assertFalse(x['readiness']['complete_90d_15m'])

if __name__=='__main__':unittest.main()

# Integration: recomputing from a later dataset must not retroactively create a
# previously unavailable signal, even when the full future path is known.
class ReplayChronology(unittest.TestCase):
    def test_prefix_ideas_reproduced_with_more_future_candles(self):
        path=ROOT/'data'/'BTCUSDT_15m_KIMI_1000.csv'
        if not path.exists():self.skipTest('historical fixture missing')
        a,_=load_csv(path,'BTCUSDT');d,_=load_csv(ROOT/'data'/'BTCUSDT_1d_KIMI_60.csv','BTCUSDT','1d')
        smaller=route_replay(a[:860],native={'1d':d});bigger=route_replay(a,native={'1d':d})
        cutoff=a[859].end
        l=[x['id'] for x in smaller['qualified_ideas'] if x['known']<=cutoff]
        r=[x['id'] for x in bigger['qualified_ideas'] if x['known']<=cutoff]
        self.assertEqual(l,r)
