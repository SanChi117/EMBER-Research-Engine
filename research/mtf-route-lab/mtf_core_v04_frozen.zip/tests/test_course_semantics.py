"""Synthetic contract cases derived from the WORDING of the teaching notes.
They are NOT annotated real screenshots and cannot certify course accuracy.
"""
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from mtf_engine import Bar,STEPS,features,simulate,TradeIdea

def bar(i,o,h,l,c,tf='1h'):
    t=i*STEPS[tf]
    return Bar(t,t+STEPS[tf],o,h,l,c,100,tf)

class SrnNotBreakout(unittest.TestCase):
    def prelude(self):
        return [bar(0,100,101,99,100),bar(1,100,102,99,101),
                bar(2,101,110,99,103),bar(3,103,105,98,104),
                bar(4,104,104,99,103),bar(5,103,113,102,112)]
    def test_breakout_not_mature_snr(self):
        x=features(self.prelude(),'1h')
        self.assertFalse(any(e.type=='SNR' for e in x))
    def test_retest_matures_only_at_close(self):
        a=self.prelude()+[bar(6,112,113,109.8,112)]
        mature=[e for e in features(a,'1h') if e.type=='SNR' and e.side=='LONG']
        self.assertEqual(len(mature),1)
        self.assertEqual(mature[0].known,a[6].end)
        self.assertIn('RETEST_AND_HOLD',mature[0].source)
    def test_failed_retest_never_matures(self):
        a=self.prelude()+[bar(6,111,112,108,108),bar(7,108,110,107,109)]
        self.assertFalse(any(e.type=='SNR' for e in features(a,'1h')))

class RbDifferentFromOb(unittest.TestCase):
    def raid_sample(self):
        return [bar(0,98,101,97,99),bar(1,99,102,98,100),
                bar(2,100,103,90,101),bar(3,101,102,97,99),
                bar(4,99,100,96,98),
                bar(5,97,100,89,95), # wick raid of level 90
                bar(6,95,99,91,96.5)] # opposing candle, NOT body engulf of 97
    def test_wick_raid_and_opposite_pair_forms_rb(self):
        a=self.raid_sample(); f=features(a,'1h')
        rb=[x for x in f if x.type=='RB' and x.side=='LONG' and x.known==a[-1].end]
        self.assertEqual(len(rb),1)
        self.assertEqual(rb[0].lo,89)
        self.assertEqual(rb[0].hi,95)
        self.assertIn('WICK',rb[0].source)
    def test_rb_not_automatically_order_block(self):
        a=self.raid_sample();f=features(a,'1h')
        self.assertFalse(any(x.type=='OB' and x.known==a[-1].end for x in f))
    def test_ob_requires_body_engulf(self):
        a=[bar(0,102,104,98,100),bar(1,99,106,97,105)]
        obs=[x for x in features(a,'1h') if x.type=='OB']
        self.assertEqual(len(obs),1)
        self.assertEqual((obs[0].lo,obs[0].hi),(98,104))

class IncompleteHistory(unittest.TestCase):
    def idea(self):
        return TradeIdea('id','A','p','tr','vc','LONG',0,100,98,104,2.0,.001,2.14,'foo','4h')
    def test_unfinished_pending_not_no_fill(self):
        b=[bar(0,101,102,100.5,101),bar(1,101,102,100.5,101)]
        out=simulate(self.idea(),b,0,expiry_bars=12)
        self.assertEqual(out['status'],'PENDING_UNRESOLVED')
    def test_expired_no_fill_is_legitimate(self):
        b=[bar(i,101,102,100.5,101) for i in range(4)]
        out=simulate(self.idea(),b,0,expiry_bars=3)
        self.assertEqual(out['status'],'NO_FILL')

if __name__=='__main__':unittest.main()
