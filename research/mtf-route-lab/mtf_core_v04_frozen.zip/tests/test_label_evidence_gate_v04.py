import hashlib,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from label_evidence_gate_v04 import validate

class EvidenceGate(unittest.TestCase):
    def label(self):
        return {'id':'unit-001','status':'VISUALLY_VERIFIED','source_url':'https://drive.google.com/file/d/example/view',
                'source_page':'lesson RB figure 1','symbol':'BTCUSDT','tf':'4h','type':'RB','side':'LONG',
                'confirmed_at':'2026-10-11T00:00:00Z','lo':100,'hi':101,'reviewer_id':'human-1',
                'reviewed_at':'2026-10-14T00:00:00Z','image_sha256':'0'*64,'image_path':'chart.png'}
    def test_flag_is_not_sufficient_for_verified(self):
        with tempfile.TemporaryDirectory() as d:
            r=validate([self.label()],d)
            self.assertEqual(r['cases_without_valid_evidence'],1)
            self.assertEqual(r['evidence_packages_with_valid_metadata'],0)
    def test_image_hash_tampering_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d,'chart.png').write_bytes(b'example chart')
            r=validate([self.label()],d)
            self.assertIn('SCREENSHOT_SHA256_MISMATCH',r['results'][0]['reasons'])
    def test_complete_metadata_only_marks_needs_human_review(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d,'chart.png');p.write_bytes(b'unit test image placeholder')
            l=self.label();l['image_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
            r=validate([l],d)
            self.assertEqual(r['evidence_packages_with_valid_metadata'],1)
            self.assertNotEqual(r['independently_human_verified'],1)
    def test_unverified_templates_not_counted(self):
        with tempfile.TemporaryDirectory() as d:
            l=self.label();l['status']='NEEDS_VISUAL_REVIEW'
            r=validate([l],d)
            self.assertEqual(r['labels_claiming_verified'],0)
            self.assertEqual(r['cases_without_valid_evidence'],0)
    def test_path_cannot_escape_evidence_root(self):
        with tempfile.TemporaryDirectory() as d:
            l=self.label();l['image_path']='../../secrets'
            r=validate([l],d)
            self.assertIn('ARTIFACT_PATH_OUTSIDE_ROOT',r['results'][0]['reasons'])
if __name__=='__main__':unittest.main()
