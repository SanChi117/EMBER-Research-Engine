import sys,hashlib,io,zipfile,unittest
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from get_history_vision import archive,pull,parse_zip
from mtf_engine import STEPS

def pack(day,tf):
    period=STEPS[tf];rows=[]
    for j in range(86400000//period):
        start=day+j*period
        row=[str(start),'100','102','99','101','50',str(start+period-1),'5050','11','25','2525','0']
        rows.append(','.join(row))
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('BTCUSDT-'+tf+'-test.csv','\n'.join(rows)+'\n')
    blob=buffer.getvalue();return blob,hashlib.sha256(blob).hexdigest()
class Vision(unittest.TestCase):
    def test_parses_csv_zip_correctly(self):
        blob,checksum=pack(0,'15m')
        a=parse_zip(blob,'test.zip');self.assertEqual(len(a),96);self.assertEqual(int(a[0][0]),0)
    def test_rejects_wrong_checksum(self):
        blob,checksum=pack(0,'1d')
        def f(url):return b'000000BAD  file.zip' if url.endswith('.CHECKSUM') else blob
        with self.assertRaisesRegex(ValueError,'checksum'):archive('BTCUSDT','1d','2026-04',fetch=f,daily='2026-04-01')
    def test_accepts_valid_checksum(self):
        blob,checksum=pack(0,'1d')
        def f(url):return (checksum+'  file.zip').encode() if url.endswith('.CHECKSUM') else blob
        a,source=archive('BTCUSDT','1d','2026-04',fetch=f,daily='2026-04-01');self.assertEqual(len(a),1)
if __name__=='__main__':unittest.main()
