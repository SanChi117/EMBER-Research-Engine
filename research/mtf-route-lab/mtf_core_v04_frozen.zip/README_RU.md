# 14.10.2026 — дополнение: дистанционный аудит Binance Futures

Получены реальные результаты проверки 93 600 15m и 5 080 1D свечей через Binance public connector; 0 выявленных пропусков и 0 конфликтов агрегирования 15m→1D. Это **не** сохранённый локально raw dataset и **не** полноценный MTF-бэктест. Точное описание в `docs/10_ПРОВЕРКА_ПОЛНОЙ_ИСТОРИИ_BINANCE_CONNECTOR_20261014.md`, машиночитаемые результаты в `results_04/BINANCE_FUTURES_CONNECTOR_REMOTE_AUDIT.json`. Алгоритм/параметры MTF заморожены, терминал и V2.2 не тронуты.

---

# Дополнение v0.4: строгий аудит источников и учебной разметки (14.10.2026)

**ВАЖНО: BTC fixture из Kimi — Binance SPOT, не USD-M Futures; последние 15m/1D свечи неполные.** Обнаружено при независимой сверке с публичными API 14.10.2026. Поэтому любые старые результаты v0.2/v0.3 на этом fixture — только проверки кода, не фьючерсная торговая статистика. Проверка без исходного манифеста теперь не может выдавать `READY_FOR_RESEARCH`. Честный статус многомонетного бэктеста: **BLOCKED_HISTORY**.

Код алгоритма и параметры v0.3 **не изменены**. Новые файлы: `src/history_gate_v04.py`, `src/source_fingerprint_v04.py`, `src/obtain_history_v04.py`, `src/label_evidence_gate_v04.py`, `src/run_portfolio_grid_v04.py`. Проверено **113/113 тестов**. Критические доказательства и ограничение в `docs/09_ПРОВЕРКА_ИСТОЧНИКА_И_БЛОКИРУЮЩИЙ_АУДИТ_V04.md`. Для полного запуска в сети: `FULL_REPLAY_STRICT.bat` или `.sh`.

---

# MTF Route Lab 0.3 — отдельная PAPER-ветка, 14.10.2026

**Статус: ENGINEERING PASS / TRADING EDGE NOT PROVEN / LONG BACKTEST BLOCKED.**

Это развитие **существующей** учебной MTF-модели, не новая стратегия. Терминал, Work, GitHub-проекты, TradingView, пользовательская frozen V2.2 и реальные ордера **не изменены**. Исходный отдельный архив v0.2 и его оригинальные результаты остаются неизменными. Здесь нет приватных биржевых ключей и методов размещения заказов.

## Подтверждённые исправления относительно 0.2

- RB от старого IMB требует взаимодействия **тенью**, а не простого пересечения двух свечей с какой угодно IMB. IMB, который появился лишь при закрытии второй RB-свечи, не может задним числом обосновывать RB. Для RB с рейдом нужен рейд в допустимом направлении. Проверено синтетическими регрессиями; учебные иллюстрации не размечены.
- Включена отдельно разрешённая учебником ветка **4H VC → 1H IDM** при наличии старшего ежедневного якоря и найденного после VC фрактального 1H IDM; **не нужен** 15m BOS. В таблицах суммируется в Route B, но в `note` отмечен `SUBROUTE=4H_VC_TO_1H_IDM` и `STRONGHL=PROXY`. Ветка 1H VC→15m IDM сохранена. Применение дневного якоря и StrongHL всё ещё исследовательская модель, не точная авторская разметка.
- Учебная оговорка: 1H IMB как триггер Route A допускается только с **4H RB/SNR**, но не с вложенным **4H IMB**. Это не отдельный универсальный фильтр, а уточнение исходного маршрута.
- Стоп для A при рейде/IMB-trigger теперь берётся за экстремум от первого теста 4H POI до 1H trigger; прежняя граница зоны триггера не подменяет весь интервал. Это **StrongHL proxy**, пока не проверен по графикам.
- Комиссии и проскальзывание стали параметрами `--fee`, `--slippage` для **обоих** компонентов плановой заявки и исполнения; стресс ×2 выполняется тем же кодом. В журнале `FTA_PIVOT_PROXY`, `STRONGHL_PROXY`.
- Строгий валидатор 5×(15m/1d) истории останавливает прогон при дырках, неверных границах, SHA-несовпадении или расхождении агрегированной 15m свечи с настоящей 1D.
- `run_research_v03.py` запускает заранее фиксированную сетку 2 FTA × 2 cost-сценария на 5 монетах, с тремя хронологическими блоками и описательными BTC 5D режимами. При неполной истории печатает `BLOCKED_HISTORY` и не выводит выдуманные сделки.

## Первичные источники

Документация учебной модели в `docs/01_МЕХАНИКА_ИЗ_УРОКОВ.md`, карта прямых Google Drive ссылок в `docs/02_ИСТОЧНИКИ.md`; строгий протокол в `docs/03_ПРОТОКОЛ.md`. Студенческое `Volume Confirmation` = **структурное** IMB/SNR/RB, не повышение SMA объёма. Маршруты A/B/C не заменяются общей конструкцией sweep→BOS→retest. Route C — лишь 15m PROXY исходной 3–5m BOS ветки.

**ВАЖНО:** первичные текстовые правила сверены с Google Drive 14.10.2026, но внешние иллюстрации/скриншоты из Notion/S3 визуально не аттестованы. `VISUALLY_VERIFIED` примеров: **0**, точность графической разметки — **UNKNOWN**, не 100%. Остались учебные пути 4H liquidity raid→1H VC и 1H POI→15m VC без триггера: полная авторская семантика ещё не реализована. Запрещено называть данную реализацию полного курса подтверждённой.

## Проверить собственноручно (Python ≥3.10)

```bash
python -m unittest discover -s tests -v
python -m compileall -q src tests
python src/mtf_engine.py --csv data/BTCUSDT_15m_KIMI_1000.csv --htf-1d data/BTCUSDT_1d_KIMI_60.csv --out results_03/course_base --fta-policy COURSE_PARENT_FTA
python src/mtf_engine.py --csv data/BTCUSDT_15m_KIMI_1000.csv --htf-1d data/BTCUSDT_1d_KIMI_60.csv --out results_03/v22_base --fta-policy V22_FIRST_OBSTACLE
python src/mtf_engine.py --csv data/BTCUSDT_15m_KIMI_1000.csv --htf-1d data/BTCUSDT_1d_KIMI_60.csv --out results_03/course_cost_x2 --fta-policy COURSE_PARENT_FTA --fee .001 --slippage .0004
python src/mtf_engine.py --csv data/BTCUSDT_15m_KIMI_1000.csv --htf-1d data/BTCUSDT_1d_KIMI_60.csv --out results_03/v22_cost_x2 --fta-policy V22_FIRST_OBSTACLE --fee .001 --slippage .0004
```

Чистый длинный архив Binance USD-M можно получить **только при работающем публичном интернете**:

```bash
python src/get_history_vision.py --symbols BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,BCHUSDT --start-15m 2026-04-01T00:00:00Z --start-1d 2024-01-01T00:00:00Z --end 2026-10-13T00:00:00Z --out data/history
python src/validate_history_v03.py --data-dir data/history --out results_03/history_audit.json
python src/run_research_v03.py --data-dir data/history --out results_03/multicoin
```

Публикация `.CHECKSUM` и ежедневных файлов на Binance Vision может отставать, REST `src/get_history.py` — альтернативный публичный источник. CSV нельзя считать Binance Futures по одному названию: провенанс должен быть подтверждён. Локальная среда 14.10.2026 не смогла разрешить домен Binance; **длинные файлы не получены**, валидатор корректно сохранил `BLOCKED_HISTORY` (10 отсутствующих файлов). Не выдавать этот этап за законченный.

## Протокол и смысл метрик

- Заморожены два FTA: `COURSE_PARENT_FTA` и `V22_FIRST_OBSTACLE`, без авто-переключения по результатам.
- `BASE`: fee 0.05% + slippage 0.02% с каждой стороны; `COST_X2`: 0.10% + 0.04%. Это исходные модельные допущения, **не** реальные тарифы счёта.
- Обе ветки IDM сохраняют лимитную идею отдельно от факта касания/исполнения; same-candle TP-before-fill неизвестен, TP/SL одной свечой = SL-first; gap stop ухудшается. Это эмуляция свечного касания, **не биржевое подтверждение fill**.
- Идеи могут перекрываться. `total_R_independent` не портфельный PnL. Невозможно честно сообщить portfolio MaxDD, если нет моделирования совместных позиций и жизненного цикла реальных заявок. Возможный `max_cumulative_R_drawdown_independent_not_portfolio` — только последовательный диагностический показатель.
- Блоки длинного исследования: апрель–июнь, июль–август, сентябрь–октябрь 2026. Описательная классификация BTC 5D по порогу ±2% **не фильтр входа**, порог не оптимизировался. История октября **уже смотрелась** при разработке: `NOT_UNTOUCHED_OOS`.
- Предикаты session, OI, funding и macro без point-in-time записи — `UNKNOWN`. Отсутствуют tick/lot/min_notional, подтверждение частичных fill/ордера, funding history, mark-price/liquidation и действительный портфель. Бэктест будущей live-прибыльности **не доказан**.

См. `docs/05_АУДИТ_V03_20261014.md`, `results_03/`, `MANIFEST_V03.json` и `TESTS_V03.txt`.


## Дополнение: Kimi engineering audit 14.10.2026 (без изменения 0.3)

После внешнего сравнения Kimi внедрены **только** инженерные проверки в `src/kimi_replay_audit.py`. 69/69 тестов PASS; 8/8 prefix invariance и 2/2 lifecycle passes на короткой BTC истории. Три MTF маршрута, FTA, параметры стратегии и код `src/mtf_engine.py` не менялись. Документ: `docs/06_КИМИ_АУДИТ_И_ЗАИМСТВОВАНИЯ_20261014.md`.

## Отдельное расширение: MTF 0.3 VALIDATION PLUS (14.10.2026)

Торговая логика **не изменена** (подтверждается `python src/check_frozen_engine_v03.py`). Добавлен самостоятельный хронологический PAPER portfolio-model: один активный order/position на монету, ограничение на 2 позиции и общий номинал, фиксация модельных fills, закрытые и MTM кривые, SL-first и gap-risk, четырёхвариантная FTA×cost сетка. См. `docs/08_ИТОГОВЫЙ_ИНЖЕНЕРНЫЙ_АУДИТ.md`.

Быстрый полностью повторяемый запуск короткого **BTC fixture** (НЕ долгий backtest):

```bash
python -m unittest discover -s tests -q
python src/check_frozen_engine_v03.py
python src/paper_portfolio_v03.py --sample --policy COURSE_PARENT_FTA --out results_03/portfolio_sample_course
python src/paper_portfolio_v03.py --sample --policy V22_FIRST_OBSTACLE --out results_03/portfolio_sample_v22
```

Для пяти монет: запустить `FULL_REPLAY.bat` на Windows либо `bash FULL_REPLAY.sh` на Linux/Unix. Скрипты получают USD-M Futures с официальными архивными checksums (резерв: Futures REST), проверяют 10 CSV и только затем переходят к 2 FTA × 2 costs + портфельной модели. Выходы `results_03/full_validation/`. Если история недоступна, возвращают код 2 / `BLOCKED_HISTORY`. Работа с реальными ордерами полностью отсутствует.

**Важная находка:** старые директории `results_course_fta` и `results_v22_fta` в наследуемой копии остались от предшествующих прогонов, НЕ являются источником новой портфельной статистики v0.3. Новые идеи валидации пересчитываются напрямую кодом v0.3 и сохраняются в `FRESH_IDEAS.jsonl`.
